# -*- coding: utf-8 -*-
"""
Duplicate-page detection for scanned PDF case files.

Page pairs are classified as:
  exact : identical rendering (footer "Order Id" stamps of the upload portal ignored) -> removed
  same  : same sheet of paper (re-scan / phone photo): after precise alignment neither
          page has ink the other lacks, and their text layers (if any) agree            -> removed
  near  : aligned and very close, but one page has extra ink (stamp, signature,
          handwriting, other numbers) or they only partly overlap                       -> kept, reported

When in doubt a page is kept: a missed duplicate costs a page, a wrong removal loses data.
Python 3.8+ compatible.
"""
import ctypes
import hashlib
import io
import os
import re
from collections import OrderedDict

import cv2
import numpy as np
import pypdfium2 as pdfium

cv2.setNumThreads(1)                # parallelism comes from worker processes

ENGINE_VERSION = "1.0"
LONG_SIDE = 1000                    # screening render (longest side, px)
HI_SIDE = 1800                      # verification render: small print stays legible
ORB_FEATURES = 1200
PHASH_MAX = 22                      # candidate pre-filter, 0..64
MIN_INLIERS = 60
MIN_INLIER_RATIO = 0.5
FULL_COVER = 0.85                   # "same" needs both pages to overlap at least this much
INK_STRONG = 150                    # darkest-channel value that is clearly ink
INK_WEAK = 235                      # ...that is enough to "explain" the other page's ink
TOL_PX = 2                          # registration tolerance (px at HI_SIDE) for sharp scans
TOL_SCALE = 1.6                     # ...grows with the source-pixel footprint of blurrier captures
MIN_BLOB = 15                       # ink px; smaller isolated specks are scan noise
SAME_MAX_INK = 60                   # ink one page may have that the other lacks, for "same"
STRICT_MAX_INK = 12                 # strict mode: both pages must be practically identical
STRICT_COVER = 0.92
DETAIL_MAX_INK = 6000               # fine detail a sharp scan may show that a phone photo lost
NEAR_MAX_INK = 5000                 # up to this a kept pair is reported as "very close"
MAX_PAGES_FULL = 1500               # larger files: exact duplicates only
MAX_VERIFY_PAIRS = 3000             # safety cap per file
CROP_SEARCH_MAX_PAGES = 300         # crop/zoom search (pairs whose overall look differs) up to this size
HI_CACHE = 6                        # hi-res pages kept in memory
COMPRESS_DPI = 150                  # page images are stored at most at this resolution (agreed with the user)
JPEG_QUALITY = 70
THUMB = 256                         # size of the check images used to verify a written file
ECC_SIDE = 500                      # size for sub-pixel alignment refinement of close calls
ECC_RETRY_INK = 1500                # close calls (ink up to this) get the refinement

_IMG = pdfium.raw.FPDF_PAGEOBJ_IMAGE
_FOOTER = re.compile(r"Order\s*Id\s*:?\s*\d+\s*-\s*[\d/]+", re.I)


def _odd(n):
    n = max(1, int(n))
    return n if n % 2 else n + 1


# ------------------------------------------------------------------ reading pages
def _source_pixels(page):
    """(area, longest side) in pixels of the largest embedded image; (0, 0) for vector/text pages.
    Used to pick the sharpest copy and to size the registration tolerance."""
    best = (0, 0)
    try:
        for obj in page.get_objects(filter=[_IMG], max_depth=2):
            try:
                w, h = obj.get_px_size()
            except Exception:
                m = obj.get_metadata()
                w, h = m.width, m.height
            best = max(best, (int(w) * int(h), max(int(w), int(h))))
    except Exception:
        pass
    return best


def _visible_text(page, tp):
    """Text of visible text objects only: invisible OCR layers of scans are noise."""
    raw = pdfium.raw
    parts = []
    for obj in page.get_objects(filter=[raw.FPDF_PAGEOBJ_TEXT], max_depth=3):
        try:
            if raw.FPDFTextObj_GetTextRenderMode(obj.raw) == raw.FPDF_TEXTRENDERMODE_INVISIBLE:
                continue
            n = raw.FPDFTextObj_GetText(obj.raw, tp.raw, None, 0)
            if n <= 2:
                continue
            buf = ctypes.create_string_buffer(n)
            raw.FPDFTextObj_GetText(obj.raw, tp.raw, ctypes.cast(buf, ctypes.POINTER(raw.FPDF_WCHAR)), n)
            parts.append(buf.raw[:n - 2].decode("utf-16-le", "ignore"))
        except Exception:
            continue
    return "".join(parts)


def _text_info(page):
    """(signature of the visible text, portal-footer rectangles in PDF units)."""
    try:
        tp = page.get_textpage()
    except Exception:
        return "", []
    try:
        rects = []
        if _FOOTER.search(tp.get_text_range() or ""):
            for i in range(tp.count_rects()):
                l, b, r, t = tp.get_rect(i)
                if _FOOTER.search(tp.get_text_bounded(l, b, r, t) or ""):
                    rects.append((l, b, r, t))
        txt = re.sub(r"\s+", " ", _FOOTER.sub("", _visible_text(page, tp))).strip()   # a space is content
        sig = hashlib.md5(txt.encode("utf-8", "replace")).hexdigest() if txt else ""
        return sig, rects
    except Exception:
        return "", []
    finally:
        tp.close()


def _render(page, long_side, gray, footers):
    w, h = page.get_size()
    scale = float(long_side) / max(w, h, 1.0)
    bm = page.render(scale=scale, grayscale=gray, fill_color=(255, 255, 255, 255))
    try:
        arr = np.array(bm.to_numpy(), copy=True)
    finally:
        bm.close()
    if arr.ndim == 3:
        arr = arr[:, :, :3]
        arr = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY) if gray else arr.min(axis=2)
    if footers and page.get_rotation() == 0:
        for l, b, r, t in footers:        # blank the portal's "Order Id" footer
            x0, x1 = int(l * scale) - 3, int(r * scale) + 3
            y0, y1 = int((h - t) * scale) - 3, int((h - b) * scale) + 3
            arr[max(0, y0):max(0, y1), max(0, x0):max(0, x1)] = 255
    return np.ascontiguousarray(arr)


def _target_size(page, long_side):
    w, h = page.get_size()
    scale = float(long_side) / max(w, h, 1.0)
    return int(np.ceil(w * scale)), int(np.ceil(h * scale))


def _fast_scan_image(page, long_side):
    """Screening image of a plain scanned page (one full-page JPEG, nothing else) straight from
    the JPEG with reduced-size decoding: several times faster than rendering. Returns None when the
    page is anything but that simple case; the caller then renders it with PDFium."""
    raw = pdfium.raw
    try:
        if raw.FPDFPage_GetAnnotCount(page.raw) != 0:
            return None
        objs = list(page.get_objects(max_depth=1))
        if len(objs) != 1 or objs[0].type != _IMG:
            return None
        img = objs[0]
        if [f for f in img.get_filters()] != ["DCTDecode"]:
            return None
        if img.get_metadata().colorspace not in (raw.FPDF_COLORSPACE_DEVICEGRAY, raw.FPDF_COLORSPACE_DEVICERGB):
            return None
        a, b, c, d, e, f = img.get_matrix().get()
        if abs(b) > 1e-6 or abs(c) > 1e-6 or a <= 0 or d <= 0:
            return None
        l, bt, r, t = img.get_bounds()
        pl, pb, pr, pt = page.get_bbox()
        pw, ph = pr - pl, pt - pb
        if abs(l - pl) > 0.01 * pw or abs(r - pr) > 0.01 * pw or abs(bt - pb) > 0.01 * ph or abs(t - pt) > 0.01 * ph:
            return None
        data = np.frombuffer(bytes(img.get_data(decode_simple=False)), np.uint8)
        pw_px, ph_px = img.get_px_size()
        red = 1
        for r_ in (8, 4, 2):
            if max(pw_px, ph_px) / r_ >= long_side * 1.05:
                red = r_
                break
        flag = {1: cv2.IMREAD_GRAYSCALE, 2: cv2.IMREAD_REDUCED_GRAYSCALE_2,
                4: cv2.IMREAD_REDUCED_GRAYSCALE_4, 8: cv2.IMREAD_REDUCED_GRAYSCALE_8}[red]
        g = cv2.imdecode(data, flag)
        if g is None:
            return None
        rot = page.get_rotation() % 360
        if rot:
            g = np.rot90(g, k={90: 3, 180: 2, 270: 1}[rot])
        tw, th = _target_size(page, long_side)
        if abs(g.shape[1] / float(g.shape[0]) - tw / float(th)) > 0.02 * (tw / float(th)):
            return None
        return np.ascontiguousarray(cv2.resize(g, (tw, th), interpolation=cv2.INTER_AREA))
    except Exception:
        return None


def screen_image(page, footers):
    g = None if footers else _fast_scan_image(page, LONG_SIDE)
    return g if g is not None else _render(page, LONG_SIDE, True, footers)


def _phash_rotations(gray):
    small = cv2.resize(gray, (32, 32), interpolation=cv2.INTER_AREA).astype(np.float32)
    out = []
    for k in range(4):
        d = cv2.dct(np.ascontiguousarray(np.rot90(small, k)))[:8, :8]
        out.append(np.packbits((d > np.median(d)).flatten()))
    return np.stack(out)


_POP = np.array([bin(i).count("1") for i in range(256)], np.uint8)


def _phash_dist(a4, b4):
    return int(_POP[np.bitwise_xor(a4[0][None, :], b4)].sum(axis=1).min())


class Page(object):
    __slots__ = ("idx", "gray", "md5", "ph", "src_px", "src_long", "text", "footers", "kp", "des",
                 "kps", "dess")

    def __init__(self, idx, gray, src, text, footers):
        self.idx = idx
        self.gray = gray
        self.md5 = hashlib.md5(gray.tobytes() + str(gray.shape).encode()).hexdigest()
        self.ph = _phash_rotations(gray)
        self.src_px, self.src_long = src
        self.text = text
        self.footers = footers
        self.kp = None
        self.des = None
        self.kps = None
        self.dess = None


_orb = None
_orb_small = None


def _quick_related(a, b):
    """Cheap test on small images: do the two pages show the same material, even when one is only
    a crop or a zoomed part of the other? (Their overall look can then be completely different.)"""
    global _orb_small, _bf
    for p in (a, b):
        if p.kps is None:
            if _orb_small is None:
                _orb_small = cv2.ORB_create(400)
            s = 600.0 / max(p.gray.shape)
            g = cv2.resize(p.gray, None, fx=s, fy=s, interpolation=cv2.INTER_AREA) if s < 1 else p.gray
            kp, des = _orb_small.detectAndCompute(g, None)
            p.kps = np.float32([k.pt for k in kp]) if kp else np.zeros((0, 2), np.float32)
            p.dess = des
    if a.dess is None or b.dess is None or len(a.kps) < 25 or len(b.kps) < 25:
        return False
    if _bf is None:
        _bf = cv2.BFMatcher(cv2.NORM_HAMMING)
    good = [m[0] for m in _bf.knnMatch(b.dess, a.dess, k=2) if len(m) == 2 and m[0].distance < 0.75 * m[1].distance]
    if len(good) < 25:
        return False
    H, mask = cv2.findHomography(np.float32([b.kps[m.queryIdx] for m in good]),
                                 np.float32([a.kps[m.trainIdx] for m in good]), cv2.RANSAC, 5.0)
    return H is not None and mask is not None and int(mask.sum()) >= 20
_bf = None


def _features(p):
    global _orb
    if p.kp is None:
        if _orb is None:
            _orb = cv2.ORB_create(ORB_FEATURES)
        kp, des = _orb.detectAndCompute(p.gray, None)
        p.kp = np.float32([k.pt for k in kp]) if kp else np.zeros((0, 2), np.float32)
        p.des = des


# ------------------------------------------------------------------ comparing two pages
def _align(a, b):
    """Homography that maps page b onto page a (screening resolution), or None."""
    global _bf
    _features(a)
    _features(b)
    if a.des is None or b.des is None or len(a.kp) < 50 or len(b.kp) < 50:
        return None
    if _bf is None:
        _bf = cv2.BFMatcher(cv2.NORM_HAMMING)
    good = [p[0] for p in _bf.knnMatch(b.des, a.des, k=2)
            if len(p) == 2 and p[0].distance < 0.75 * p[1].distance]
    if len(good) < MIN_INLIERS:
        return None
    src = np.float32([b.kp[m.queryIdx] for m in good])
    dst = np.float32([a.kp[m.trainIdx] for m in good])
    H, mask = cv2.findHomography(src, dst, cv2.RANSAC, 4.0)
    if H is None or mask is None:
        return None
    inl = int(mask.sum())
    if inl < MIN_INLIERS or inl < MIN_INLIER_RATIO * len(good):
        return None
    return H, inl


def _flatten(g):
    """Remove uneven lighting / paper tint so that background ~255 and ink stays dark.
    The background is estimated on a 4x smaller copy (same result, far faster)."""
    h, w = g.shape
    s = cv2.resize(g, (max(8, w // 4), max(8, h // 4)), interpolation=cv2.INTER_AREA)
    k = _odd(max(s.shape) * 0.025)
    bg = cv2.morphologyEx(s, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
    bg = cv2.GaussianBlur(bg, (0, 0), k * 0.5)
    bg = cv2.resize(bg, (w, h), interpolation=cv2.INTER_LINEAR)
    f = g.astype(np.float32) * 255.0 / np.maximum(bg.astype(np.float32), 1.0)
    return np.clip(f, 0, 255).astype(np.uint8)


def _refine(a, b, H):
    """Sub-pixel refinement of H (b -> a) with ECC at reduced size; H unchanged if ECC fails."""
    try:
        s = float(ECC_SIDE) / max(a.gray.shape)
        t = float(ECC_SIDE) / max(b.gray.shape)
        ga = cv2.resize(_flatten(a.gray), None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
        gb = cv2.resize(_flatten(b.gray), None, fx=t, fy=t, interpolation=cv2.INTER_AREA)
        Hs = np.diag([s, s, 1.0]).dot(H).dot(np.diag([1.0 / t, 1.0 / t, 1.0]))
        warp = np.linalg.inv(Hs)
        warp = (warp / warp[2, 2]).astype(np.float32)
        crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 40, 1e-5)
        _, warp = cv2.findTransformECC(ga.astype(np.float32) / 255.0, gb.astype(np.float32) / 255.0,
                                       warp, cv2.MOTION_HOMOGRAPHY, crit, None, 3)
        Hr = np.diag([1.0 / s, 1.0 / s, 1.0]).dot(np.linalg.inv(warp.astype(np.float64))).dot(np.diag([t, t, 1.0]))
        h, w = b.gray.shape
        corners = np.float32([[0, 0], [w, 0], [0, h], [w, h]]).reshape(-1, 1, 2)
        d = np.abs(cv2.perspectiveTransform(corners, Hr) - cv2.perspectiveTransform(corners, H)).max()
        return Hr if d < 12 else H
    except Exception:
        return H


def _local_warp(fa, fb):
    """Correct small local distortions (paper curl, lens, scanner skew): estimate a shift per
    tile by template matching, smooth the shift field, and remap fb onto fa."""
    h, w = fa.shape
    T = max(64, int(max(h, w) / 14))
    R = max(4, int(max(h, w) * 0.006))
    ys, xs = list(range(0, h - T // 2, T)), list(range(0, w - T // 2, T))
    dx = np.zeros((len(ys), len(xs)), np.float32)
    dy = np.zeros_like(dx)
    ok = np.zeros(dx.shape, bool)
    for gi, y0 in enumerate(ys):
        for gj, x0 in enumerate(xs):
            y1, x1 = min(h, y0 + T), min(w, x0 + T)
            ta = fa[y0:y1, x0:x1]
            if ta.std() < 12 or (ta < INK_STRONG).sum() < 40:
                continue
            yb0, xb0 = max(0, y0 - R), max(0, x0 - R)
            tb = fb[yb0:min(h, y1 + R), xb0:min(w, x1 + R)]
            if tb.shape[0] < ta.shape[0] or tb.shape[1] < ta.shape[1] or tb.std() < 12:
                continue
            res = cv2.matchTemplate(tb, ta, cv2.TM_CCOEFF_NORMED)
            _, mx, _, loc = cv2.minMaxLoc(res)
            if mx >= 0.35:
                dx[gi, gj] = loc[0] - (x0 - xb0)
                dy[gi, gj] = loc[1] - (y0 - yb0)
                ok[gi, gj] = True
    if not ok.any():
        return fb
    fill_x, fill_y = float(np.median(dx[ok])), float(np.median(dy[ok]))
    dx[~ok], dy[~ok] = fill_x, fill_y
    if min(dx.shape) >= 3:
        dx = cv2.medianBlur(dx, 3)
        dy = cv2.medianBlur(dy, 3)
    # tile centres -> dense field
    fx = cv2.resize(dx, (w, h), interpolation=cv2.INTER_LINEAR)
    fy = cv2.resize(dy, (w, h), interpolation=cv2.INTER_LINEAR)
    gx, gy = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    return cv2.remap(fb, gx + fx, gy + fy, cv2.INTER_LINEAR, borderValue=255)


def _unexplained_ink(fa, fb, valid, tol):
    """Ink in fa that has no ink within tol px in fb (both aligned, flattened)."""
    k = np.ones((2 * tol + 1, 2 * tol + 1), np.uint8)
    only = (fa < INK_STRONG) & ~(cv2.dilate((fb < INK_WEAK).astype(np.uint8), k) > 0) & valid
    only = only.astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(cv2.dilate(only, np.ones((5, 5), np.uint8)))
    if n <= 1:
        return 0
    cnt = np.bincount(lab[only > 0].ravel(), minlength=n)
    L = max(fa.shape)
    total = 0
    for i in range(1, n):
        if cnt[i] < MIN_BLOB:
            continue
        w, h = st[i, 2], st[i, 3]
        if max(w, h) > 0.25 * L and min(w, h) <= 14:
            continue                     # scanner streak / fold line
        total += int(cnt[i])
    return total


def compare(a, b, hi, ecc=False, al=None):
    """Measure a candidate pair. Returns dict or None when the pages are unrelated.
    ink_a = ink found only on page a, ink_b = only on page b."""
    al = al or _align(a, b)
    if al is None:
        return None
    H, inl = al
    if ecc:
        H = _refine(a, b, H)
    fa, fb = hi.get(a.idx), hi.get(b.idx)
    sa = fa.shape[1] / float(a.gray.shape[1])
    sb = fb.shape[1] / float(b.gray.shape[1])
    Hh = np.diag([sa, sa, 1.0]).dot(H).dot(np.diag([1.0 / sb, 1.0 / sb, 1.0]))
    h, w = fa.shape
    fb_w = cv2.warpPerspective(fb, Hh, (w, h), flags=cv2.INTER_LINEAR, borderValue=255)
    valid = cv2.warpPerspective(np.full(fb.shape, 255, np.uint8), Hh, (w, h), flags=cv2.INTER_NEAREST) > 0
    cov_a = float(valid.mean())
    mb = np.zeros(fb.shape, np.uint8)               # page b's own borders (photo edges, lid shadow)
    yb, xb = int(0.03 * fb.shape[0]), int(0.03 * fb.shape[1])
    mb[yb:fb.shape[0] - yb, xb:fb.shape[1] - xb] = 255
    inner_b = cv2.warpPerspective(mb, Hh, (w, h), flags=cv2.INTER_NEAREST) > 0
    # registration tolerance grows with the blur of the coarser capture (one source pixel in hi-res px)
    zoom = float(np.sqrt(abs(np.linalg.det(Hh[:2, :2]))))
    foot_a = HI_SIDE / float(a.src_long) if a.src_long else 0.5
    foot_b = (HI_SIDE / float(b.src_long) if b.src_long else 0.5) * zoom
    tol = int(min(5, max(TOL_PX, round(TOL_SCALE * max(foot_a, foot_b)))))
    try:
        back = cv2.warpPerspective(np.full(fa.shape, 255, np.uint8), np.linalg.inv(Hh),
                                   (fb.shape[1], fb.shape[0]), flags=cv2.INTER_NEAREST) > 0
        cov_b = float(back.mean())
    except np.linalg.LinAlgError:
        cov_b = 0.0
    fb_w = _local_warp(fa, fb_w)
    m = _odd(0.012 * max(h, w))
    valid = cv2.erode(valid.astype(np.uint8), np.ones((m, m), np.uint8)) > 0
    by, bx = int(0.03 * h), int(0.03 * w)         # scanner borders / lid shadows
    valid[:by, :] = False
    valid[h - by:, :] = False
    valid[:, :bx] = False
    valid[:, w - bx:] = False
    valid &= inner_b
    ink_a = _unexplained_ink(fa, fb_w, valid, tol)
    ink_b = _unexplained_ink(fb_w, fa, valid, tol)
    cover = min(cov_a, cov_b)
    text_ok = (a.text == b.text) or not (a.text or b.text)
    return {"ink_a": ink_a, "ink_b": ink_b, "cover": round(cover, 2), "inliers": inl,
            "text_ok": text_ok, "tol": tol, "al": al}


def removable(r, pa, pb, strict=False):
    """Can page pb be dropped in favour of page pa (r = compare(pa, pb))?
    strict: only when the two pages are practically identical (no sharper-scan exception)."""
    if strict:
        return (r["text_ok"] and r["cover"] >= STRICT_COVER
                and r["ink_a"] <= STRICT_MAX_INK and r["ink_b"] <= STRICT_MAX_INK)
    if not r["text_ok"] or r["cover"] < FULL_COVER or r["ink_b"] > SAME_MAX_INK:
        return False                    # pb carries something pa lacks
    if r["ink_a"] <= SAME_MAX_INK:
        return True                     # identical content
    # pa shows detail pb lacks: fine only when pa is a much sharper capture (scan vs phone photo)
    return pa.src_px >= 2.5 * max(pb.src_px, 1) and r["ink_a"] <= DETAIL_MAX_INK


class _HiRes(object):
    """Verification renders (darkest colour channel, flattened), made on demand, LRU-cached."""

    def __init__(self, pdf, pages):
        self.pdf, self.pages, self.cache = pdf, pages, OrderedDict()

    def get(self, idx):
        if idx in self.cache:
            self.cache.move_to_end(idx)
            return self.cache[idx]
        page = self.pdf[idx]
        try:
            img = _flatten(_render(page, HI_SIDE, False, self.pages[idx].footers))
        finally:
            page.close()
        self.cache[idx] = img
        if len(self.cache) > HI_CACHE:
            self.cache.popitem(last=False)
        return img


# ------------------------------------------------------------------ one file
def open_pdf(path):
    """Open through a Python file object: works with Persian and very long Windows paths."""
    f = open(path, "rb")
    try:
        return pdfium.PdfDocument(f, autoclose=True)
    except Exception:
        f.close()
        raise


def count_pages(path):
    pdf = open_pdf(path)
    try:
        return len(pdf)
    finally:
        pdf.close()


def analyze_pdf(path, details=False, strict=False):
    """-> dict(pages, keep=[0-based], removed=[(page, twin, kind, score)],
               near=[(page_a, page_b, score, cover)], mode). Pages in results are 1-based."""
    pdf = open_pdf(path)
    try:
        n = len(pdf)
        pages = []
        for i in range(n):
            page = pdf[i]
            try:
                text, footers = _text_info(page)
                gray = screen_image(page, footers)
                pages.append(Page(i, gray, _source_pixels(page), text, footers))
            finally:
                page.close()

        edges = []                          # (kept page, dropped page, kind, score)
        first = {}
        for p in pages:
            if p.md5 in first:
                edges.append((first[p.md5], p.idx, "exact", 0))
            else:
                first[p.md5] = p.idx
        exact_of = dict((j, i) for i, j, _, _ in edges)

        near, log = [], []
        mode = "full" if n <= MAX_PAGES_FULL else "exact-only"
        if mode == "full":
            cand = []
            reps = [p for p in pages if p.idx not in exact_of]
            crop_search = len(reps) <= CROP_SEARCH_MAX_PAGES
            for x in range(len(reps)):
                for y in range(x + 1, len(reps)):
                    d = _phash_dist(reps[x].ph, reps[y].ph)
                    if d <= PHASH_MAX:
                        cand.append((d, reps[x].idx, reps[y].idx))
                    elif crop_search and _quick_related(reps[x], reps[y]):
                        cand.append((64, reps[x].idx, reps[y].idx))
            if len(cand) > MAX_VERIFY_PAIRS:
                cand.sort()
                cand, mode = cand[:MAX_VERIFY_PAIRS], "capped"
            hi = _HiRes(pdf, pages)
            for d, i, j in sorted(cand, key=lambda c: (c[1], c[2])):
                r = compare(pages[i], pages[j], hi)
                if r is None:
                    continue
                if SAME_MAX_INK < max(r["ink_a"], r["ink_b"]) <= ECC_RETRY_INK:
                    # close call: misregistration can mimic small differences -> refine and retry
                    r2 = compare(pages[i], pages[j], hi, ecc=True, al=r["al"])
                    if r2 is not None and r2["ink_a"] + r2["ink_b"] < r["ink_a"] + r["ink_b"]:
                        r = r2
                rev = dict(r, ink_a=r["ink_b"], ink_b=r["ink_a"])
                drop_j = removable(r, pages[i], pages[j], strict)
                drop_i = removable(rev, pages[j], pages[i], strict)
                if details:
                    log.append((i + 1, j + 1, d, r, drop_i, drop_j))
                if drop_j:
                    edges.append((i, j, "same", r["ink_b"]))
                if drop_i:
                    edges.append((j, i, "same", r["ink_a"]))
                if not (drop_i or drop_j) and max(r["ink_a"], r["ink_b"]) <= NEAR_MAX_INK:
                    if not r["text_ok"]:
                        why = "text"                       # typed text differs
                    elif r["cover"] < FULL_COVER:
                        why = "crop"                       # only part of one page is on the other
                    elif strict and (removable(r, pages[i], pages[j]) or removable(rev, pages[j], pages[i])):
                        why = "similar"                    # would be removed in balanced mode
                    else:
                        why = "marks"                      # stamp / signature / handwriting / numbers differ
                    near.append((i, j, max(r["ink_a"], r["ink_b"]), r["cover"], why))
    finally:
        pdf.close()

    # keep the sharpest copy (largest source image, then earliest page); a page is dropped only
    # when it is a duplicate *of a page that is kept*
    can_drop = {}                               # kept page -> [(dropped page, kind, score)]
    for k, j, kind, score in edges:
        can_drop.setdefault(k, []).append((j, kind, score))
        if kind == "exact":
            can_drop.setdefault(j, []).append((k, kind, score))
    order = sorted(range(n), key=lambda k: (-pages[k].src_px, k))
    state, removed = {}, []
    for k in order:
        if k in state:
            continue
        state[k] = "keep"
        for j, kind, score in sorted(can_drop.get(k, [])):
            if j not in state:
                state[j] = "drop"
                removed.append((j + 1, k + 1, kind, score))
    keep = [k for k in range(n) if state.get(k) == "keep"]
    dropped = set(r[0] - 1 for r in removed)
    near_out = sorted((a + 1, b + 1, s, c, w) for a, b, s, c, w in near
                      if a not in dropped and b not in dropped)
    thumbs = [_thumb(p.gray) for p in pages]
    out = {"pages": n, "keep": keep, "removed": sorted(removed), "near": near_out, "mode": mode,
           "thumbs": thumbs}
    if details:
        out["log"] = log
    return out


def _thumb(gray):
    s = float(THUMB) / max(gray.shape)
    return cv2.resize(gray, (max(1, int(gray.shape[1] * s)), max(1, int(gray.shape[0] * s))),
                      interpolation=cv2.INTER_AREA)


def _colourless(bgr):
    """True when the image has no coloured ink at all (blue pen, red stamp, coloured print).
    Paper tint (yellowed or bluish paper) is measured first and does not count as colour."""
    h, w = bgr.shape[:2]
    s = 600.0 / max(h, w)
    t = cv2.resize(bgr, (max(1, int(w * s)), max(1, int(h * s))), interpolation=cv2.INTER_AREA) if s < 1 else bgr
    lab = cv2.cvtColor(t, cv2.COLOR_BGR2LAB).astype(np.float32)
    L, a, b = lab[:, :, 0], lab[:, :, 1] - 128.0, lab[:, :, 2] - 128.0
    paper = L >= np.percentile(L, 60)
    pa, pb = float(np.median(a[paper])), float(np.median(b[paper]))
    ink = ((np.hypot(a - pa, b - pb) > 14) & (L > 25)).astype(np.uint8)
    ink = cv2.morphologyEx(ink, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))   # drop single-pixel JPEG noise
    return int(ink.sum()) <= 10


def _compress_page_images(page):
    """Re-store the large images of one page at COMPRESS_DPI as JPEG (grey when colourless).
    Returns the number of images replaced. Anything unusual is left exactly as it was."""
    raw = pdfium.raw
    changed = 0
    for obj in list(page.get_objects(filter=[_IMG], max_depth=1)):
        try:
            filters = list(obj.get_filters())
            if any(f in ("CCITTFaxDecode", "JBIG2Decode") for f in filters):
                continue                                   # 1-bit fax/line-art: already tiny
            if obj.get_metadata().bits_per_pixel <= 1:
                continue
            w, h = obj.get_px_size()
            if w * h < 150000:
                continue                                   # signatures, logos, small pictures
            a, b, c, d, _, _ = obj.get_matrix().get()
            wpt, hpt = (a * a + b * b) ** 0.5, (c * c + d * d) ** 0.5
            if wpt < 1 or hpt < 1:
                continue
            dpi = max(w / (wpt / 72.0), h / (hpt / 72.0))
            scale = min(1.0, COMPRESS_DPI / dpi)
            if scale > 0.95 and filters == ["DCTDecode"]:
                continue                                   # already a small JPEG
            raw_len = len(obj.get_data(decode_simple=False))
            bm = obj.get_bitmap(render=False)
            try:
                if bm.format == raw.FPDFBitmap_BGRA:
                    continue                               # transparency: leave alone
                px = np.array(bm.to_numpy(), copy=True)
            finally:
                bm.close()
            if px.ndim == 3:
                px = px[:, :, :3]
                if _colourless(px):
                    px = cv2.cvtColor(px, cv2.COLOR_BGR2GRAY)
            if scale < 0.95:
                px = cv2.resize(px, (max(1, int(px.shape[1] * scale)), max(1, int(px.shape[0] * scale))),
                                interpolation=cv2.INTER_AREA)
            ok, enc = cv2.imencode(".jpg", px, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY, cv2.IMWRITE_JPEG_OPTIMIZE, 1])
            if not ok or len(enc) > 0.9 * raw_len:
                continue
            obj.load_jpeg(io.BytesIO(enc.tobytes()), pages=[page], inline=True)   # data copied in now
            changed += 1
        except Exception:
            continue
    if changed:
        page.gen_content()
    return changed


def write_output(src_path, keep, dst_path, compress=True):
    """Write the kept pages (0-based, original order) to dst_path, page images recompressed.
    Two steps on disk: PDFium only drops the old image data when images are replaced inside a
    document it has loaded from a file, so the page subset is saved first, then recompressed.
    Returns the number of images that were recompressed."""
    stage = dst_path + ".stage" if compress else dst_path
    src = open_pdf(src_path)
    new = pdfium.PdfDocument.new()
    try:
        new.import_pages(src, list(keep))
        with open(stage, "wb") as f:
            new.save(f)
    finally:
        new.close()
        src.close()
    if not compress:
        return 0
    changed = 0
    try:
        doc = open_pdf(stage)
        opened = []
        try:
            for i in range(len(doc)):               # pages stay open until the file is saved
                pg = doc[i]
                opened.append(pg)
                changed += _compress_page_images(pg)
            with open(dst_path, "wb") as f:
                doc.save(f)
        finally:
            for pg in opened:
                pg.close()
            doc.close()
    finally:
        try:
            os.remove(stage)
        except OSError:
            pass
    return changed


def verify_output(path, keep, thumbs):
    """The written file must open, have exactly the kept pages, and every page must look like the
    original page (checked on small renders). Returns None when fine, else the reason."""
    pdf = open_pdf(path)
    try:
        if len(pdf) != len(keep):
            return "wrong page count"
        for i, k in enumerate(keep):
            pg = pdf[i]
            try:
                got = _render(pg, THUMB, True, [])
            finally:
                pg.close()
            ref = thumbs[k]
            got = cv2.resize(got, (ref.shape[1], ref.shape[0]), interpolation=cv2.INTER_AREA)
            x = cv2.GaussianBlur(ref, (0, 0), 1.0).astype(np.float32).ravel()
            y = cv2.GaussianBlur(got, (0, 0), 1.0).astype(np.float32).ravel()
            if x.std() < 3 or y.std() < 3:
                if abs(float(x.mean()) - float(y.mean())) > 12:
                    return "page %d looks different" % (i + 1)
                continue
            if float(np.corrcoef(x, y)[0, 1]) < 0.85:
                return "page %d looks different" % (i + 1)
        return None
    finally:
        pdf.close()


def write_subset(src_path, keep, dst_path):
    """Write a new PDF containing only the kept pages (0-based indices, original order)."""
    src = open_pdf(src_path)
    dst = pdfium.PdfDocument.new()
    try:
        dst.import_pages(src, list(keep))
        with open(dst_path, "wb") as f:
            dst.save(f)
    finally:
        dst.close()
        src.close()
