# -*- coding: utf-8 -*-
"""
Self-test: builds a few PDFs, runs the real program on them in a temporary folder and checks the
result. Run it once on the target machine:   yektasaz.exe --selftest
It uses only what is bundled with the program (no internet, no sample files needed).
"""
import io
import os
import shutil
import sqlite3
import sys
import tempfile
import time
import traceback

OK, BAD = "[  OK  ]", "[ FAIL ]"


def _doc_image(seed, number=None, stamp=False, w=2480, h=3508):
    """A synthetic scanned page: many words/numbers at fixed places, lines and boxes, paper noise."""
    import cv2
    import numpy as np
    rng = np.random.RandomState(seed)
    img = np.full((h, w, 3), 244, np.uint8)
    img = np.clip(img.astype(np.int16) + rng.normal(0, 3, img.shape), 0, 255).astype(np.uint8)
    fonts = [cv2.FONT_HERSHEY_SIMPLEX, cv2.FONT_HERSHEY_DUPLEX, cv2.FONT_HERSHEY_COMPLEX, cv2.FONT_HERSHEY_TRIPLEX]
    for i in range(70):
        x, y = int(rng.randint(120, w - 900)), int(rng.randint(150, h - 150))
        text = "".join(rng.choice(list("0123456789ABCDEFGHKMNPRSTUVXYZ"), size=int(rng.randint(5, 11))))
        if i == 7 and number is not None:
            text = number                          # the one line that differs between two versions of a page
        cv2.putText(img, text, (x, y), fonts[i % 4], float(rng.uniform(1.3, 2.3)), (35, 35, 35), 3, cv2.LINE_AA)
    for _ in range(14):
        p1 = (int(rng.randint(80, w - 80)), int(rng.randint(80, h - 80)))
        p2 = (p1[0] + int(rng.randint(-600, 600)), p1[1] + int(rng.randint(-5, 5)))
        cv2.line(img, p1, p2, (60, 60, 60), 3)
    for _ in range(6):
        p1 = (int(rng.randint(80, w - 700)), int(rng.randint(80, h - 500)))
        cv2.rectangle(img, p1, (p1[0] + int(rng.randint(200, 600)), p1[1] + int(rng.randint(100, 400))), (70, 70, 70), 3)
    if stamp:
        cv2.circle(img, (w - 500, h - 600), 230, (30, 30, 200), 12)           # red stamp
        cv2.putText(img, "STAMP", (w - 680, h - 580), cv2.FONT_HERSHEY_DUPLEX, 3.0, (30, 30, 200), 8, cv2.LINE_AA)
    return img


def _make_pdf(path, images):
    import cv2
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument.new()
    for im in images:
        page = pdf.new_page(595, 842)
        ok, enc = cv2.imencode(".jpg", im, [cv2.IMWRITE_JPEG_QUALITY, 93])
        obj = pdfium.PdfImage.new(pdf)
        obj.load_jpeg(io.BytesIO(enc.tobytes()), inline=True)
        obj.set_matrix(pdfium.PdfMatrix().scale(595, 842))
        page.insert_obj(obj)
        page.gen_content()
        page.close()
    with open(path, "wb") as f:
        pdf.save(f)
    pdf.close()


def run():
    results = []

    def check(ok, text):
        results.append(bool(ok))
        print("%s %s" % (OK if ok else BAD, text), flush=True)

    print("=" * 66)
    print(" Yektasaz self-test | آزمون خودکار یکتاساز")
    print("=" * 66, flush=True)
    try:
        import cv2
        import numpy
        import pypdfium2
        check(True, "libraries load: opencv %s, numpy %s, pypdfium2 %s" % (cv2.__version__, numpy.__version__, str(pypdfium2.version.PYPDFIUM_INFO)))
    except Exception as e:
        check(False, "a library failed to load: %s" % e)
        return 1
    try:
        import tkinter  # noqa: F401
        check(True, "folder picker available (tkinter)")
    except Exception:
        print("[ WARN ] tkinter missing: the folder picker button will not work; type the path by hand")

    import app_core
    root = tempfile.mkdtemp(prefix="yektasaz_selftest_")
    keep_dir = False
    try:
        sub = os.path.join(root, "پوشه‌ی آزمایش")
        os.makedirs(sub)
        A = _doc_image(1)
        A2 = _doc_image(1, number="9040517")          # same page, one line changed
        C = _doc_image(2, stamp=True)
        dup = os.path.join(sub, "dup.pdf")
        single = os.path.join(root, "single.pdf")
        broken = os.path.join(root, "broken.pdf")
        t0 = time.time()
        _make_pdf(dup, [A, A, A2, C])                 # page 2 is an exact copy of page 1
        _make_pdf(single, [_doc_image(3)])
        with open(broken, "wb") as f:
            f.write(b"this is not a pdf file at all" * 50)
        sizes = dict((p, os.path.getsize(p)) for p in (dup, single, broken))
        mtimes = dict((p, os.path.getmtime(p)) for p in (dup, single))
        with open(broken, "rb") as f:
            broken_bytes = f.read()
        print("       test files built in %.1f s" % (time.time() - t0), flush=True)

        c = app_core.Controller()
        c.start_scan(root, 2, True)
        t0 = time.time()
        while c.phase not in ("ready", "finished", "error", "stopped") and time.time() - t0 < 240:
            time.sleep(0.4)
        s = c.status()
        check(c.phase in ("ready", "finished") and s.get("files") == 3 and s.get("pages", 0) >= 5,
              "scan found %s files / %s pages (expected 3 / 5+) | سه فایل پیدا شد" % (s.get("files"), s.get("pages")))
        check(all(os.path.getsize(p) == sizes[p] for p in sizes), "the estimate step changed nothing | مرحله‌ی تخمین فایلی را تغییر نداد")
        if c.phase == "ready":
            c.start_run()
            t0 = time.time()
            while c.phase not in ("finished", "error", "stopped") and time.time() - t0 < 300:
                time.sleep(0.5)
        check(c.phase == "finished", "run finished (phase=%s) | کار تمام شد" % c.phase)

        import dedup_engine as E
        n = E.count_pages(dup)
        check(n == 3, "exact copy removed, changed page kept: dup.pdf 4 -> %d pages (expected 3) | کپی دقیق حذف شد و صفحه‌ی متفاوت ماند" % n)
        check(os.path.getsize(dup) < 0.8 * sizes[dup], "dup.pdf compressed: %.1f -> %.1f MB | فشرده شد" % (sizes[dup] / 1e6, os.path.getsize(dup) / 1e6))
        check(E.count_pages(single) == 1 and os.path.getsize(single) < 0.8 * sizes[single],
              "single.pdf compressed: %.1f -> %.1f MB | فشرده شد" % (sizes[single] / 1e6, os.path.getsize(single) / 1e6))
        with open(broken, "rb") as f:
            check(f.read() == broken_bytes, "broken file left untouched | فایل خراب دست‌نخورده ماند")
        db = sqlite3.connect(os.path.join(root, "_yektasaz", "state.sqlite"))
        near = db.execute("SELECT COUNT(*) FROM near").fetchone()[0]
        bad = db.execute("SELECT COUNT(*) FROM files WHERE status='error'").fetchone()[0]
        db.close()
        check(near >= 1, "the two nearly identical pages were flagged for review (%d pair) | جفت‌صفحه‌ی خیلی نزدیک اعلام شد" % near)
        check(bad == 1, "the broken file was reported as a problem | فایل خراب در فهرست مشکل‌ها آمد")
        check(abs(os.path.getmtime(dup) - mtimes[dup]) < 2 and abs(os.path.getmtime(single) - mtimes[single]) < 2,
              "file dates preserved | تاریخ فایل‌ها حفظ شد")
        left = [f for d, _, fs in os.walk(root) for f in fs if f.endswith(".yekta-tmp") or f.endswith(".stage")]
        check(not left, "no temporary files left behind | فایل موقتی جا نماند")
        rep = os.path.join(root, "_yektasaz")
        names = ("report.html", "summary.txt", "very_close_pages.csv", "removed_pages.csv", "problems.csv", "log.txt")
        check(all(os.path.exists(os.path.join(rep, nme)) for nme in names), "reports written: " + ", ".join(names))
        check(not os.path.exists(os.path.join(rep, "running.lock")), "folder lock released | قفل پوشه آزاد شد")
    except Exception:
        traceback.print_exc()
        check(False, "the self-test crashed (see the error above)")
        keep_dir = True
    finally:
        if keep_dir or not all(results):
            print("       test folder kept for inspection: %s" % root)
        else:
            shutil.rmtree(root, ignore_errors=True)
    failed = results.count(False)
    print("=" * 66)
    if failed:
        print(" RESULT: %d of %d checks FAILED | %d مورد ناموفق" % (failed, len(results), failed))
    else:
        print(" RESULT: all %d checks passed | همه‌ی موارد درست بود" % len(results))
    print("=" * 66, flush=True)
    return 1 if failed else 0


if __name__ == "__main__":
    import multiprocessing as mp
    mp.freeze_support()
    sys.exit(run())
