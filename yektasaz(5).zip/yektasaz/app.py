# -*- coding: utf-8 -*-
"""
یکتاساز — removes duplicate pages from scanned PDF case files, folder by folder.

    python app.py                 opens the app in the browser
    python app.py --cli IN OUT    runs without a browser (servers / virtual machines)
"""
import argparse
import json
import multiprocessing as mp
import os
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

HERE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import app_core  # noqa: E402

CTRL = app_core.Controller()
_THUMB_LOCK = threading.Lock()


# ------------------------------------------------------------------ native folder dialog
def _pick_folder_child():
    """Runs in a separate process: tkinter must own its own main thread."""
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    path = filedialog.askdirectory(title="انتخاب پوشه")
    root.destroy()
    sys.stdout.write(json.dumps({"path": path or ""}))


def pick_folder():
    if getattr(sys, "frozen", False):
        cmd = [sys.executable, "--pick-folder"]
    else:
        cmd = [sys.executable, os.path.abspath(__file__), "--pick-folder"]
    try:
        out = subprocess.run(cmd, capture_output=True, timeout=900).stdout.decode("ascii", "ignore")
        return json.loads(out.strip().splitlines()[-1]).get("path", "")
    except Exception:
        return ""


def open_in_explorer(path):
    if not path or not os.path.isdir(path):
        return
    if os.name == "nt":
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


# ------------------------------------------------------------------ page thumbnails for review
def thumb_jpeg(fid, page, height):
    import cv2
    import numpy as np
    import dedup_engine as E
    st = CTRL.store
    row = st.one("SELECT rel FROM files WHERE id=?", (fid,)) if st else None
    if not row:
        return None
    with _THUMB_LOCK:
        pdf = E.open_pdf(CTRL._abs(row[0]))
        try:
            pg = pdf[page - 1]
            try:
                w, h = pg.get_size()
                bm = pg.render(scale=float(height) / max(h, 1.0), fill_color=(255, 255, 255, 255))
                arr = np.array(bm.to_numpy(), copy=True)
                bm.close()
            finally:
                pg.close()
        finally:
            pdf.close()
    if arr.ndim == 3 and arr.shape[2] == 4:
        arr = arr[:, :, :3]
    ok, buf = cv2.imencode(".jpg", arr, [cv2.IMWRITE_JPEG_QUALITY, 82])
    return buf.tobytes() if ok else None


# ------------------------------------------------------------------ HTTP API
class Handler(BaseHTTPRequestHandler):
    server_version = "yektasaz"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return {}

    def do_GET(self):
        u = urlparse(self.path)
        q = dict((k, v[0]) for k, v in parse_qs(u.query).items())
        try:
            if u.path in ("/", "/index.html"):
                with open(os.path.join(HERE, "ui.html"), "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            if u.path == "/api/status":
                return self._send(200, CTRL.status())
            if u.path == "/api/log":
                evs = CTRL.events_since(int(q.get("since", 0)))
                return self._send(200, {"seq": CTRL._seq, "events": evs})
            if u.path == "/api/near":
                st = CTRL.store
                if st is None:
                    return self._send(200, {"rows": [], "total": 0, "reasons": {}})
                off, lim = int(q.get("offset", 0)), min(int(q.get("limit", 30)), 200)
                why = q.get("reason") or None
                where, args = ("WHERE n.reason=?", (why,)) if why else ("", ())
                rows = st.q("""SELECT n.fid, f.rel, n.pa, n.pb, n.score, n.cover, n.reason FROM near n
                               JOIN files f ON f.id=n.fid %s ORDER BY n.score, n.fid, n.pa LIMIT ? OFFSET ?""" % where, args + (lim, off))
                total = st.one("SELECT COUNT(*) FROM near n %s" % where, args)[0]
                reasons = dict((r[0] or "?", r[1]) for r in st.q("SELECT reason, COUNT(*) FROM near GROUP BY reason"))
                return self._send(200, {"total": total, "reasons": reasons, "rows": [
                    {"fid": r[0], "file": r[1], "a": r[2], "b": r[3], "score": r[4], "cover": r[5], "reason": r[6]} for r in rows]})
            if u.path == "/api/problems":
                st = CTRL.store
                if st is None:
                    return self._send(200, {"rows": [], "total": 0})
                off, lim = int(q.get("offset", 0)), min(int(q.get("limit", 100)), 500)
                rows = st.q("""SELECT rel, status, error, note FROM files
                               WHERE status IN ('error','encrypted','timeout','crash','locked') OR note IS NOT NULL
                               ORDER BY id LIMIT ? OFFSET ?""", (lim, off))
                total = st.one("""SELECT COUNT(*) FROM files
                                  WHERE status IN ('error','encrypted','timeout','crash','locked') OR note IS NOT NULL""")[0]
                return self._send(200, {"total": total, "rows": [
                    {"file": r[0], "status": r[1] if r[1] != "done" else "compress", "error": r[2] if r[1] != "done" else r[3],
                     "why": app_core.explain_error(r[2] if r[1] != "done" else r[3])} for r in rows]})
            if u.path == "/report.html":
                p = os.path.join(CTRL.report_dir(), "report.html") if CTRL.inp else ""
                if not p or not os.path.exists(p):
                    return self._send(404, "گزارشی هنوز ساخته نشده است", "text/plain; charset=utf-8")
                with open(p, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            if u.path == "/font/Vazirmatn.woff2":
                p = os.path.join(HERE, "fonts", "Vazirmatn.woff2")
                if not os.path.exists(p):
                    return self._send(404, "", "text/plain")
                with open(p, "rb") as f:
                    return self._send(200, f.read(), "font/woff2")
            if u.path == "/api/thumb":
                data = thumb_jpeg(int(q["fid"]), int(q["page"]), min(int(q.get("h", 560)), 1600))
                if data is None:
                    return self._send(404, {"error": "not found"})
                return self._send(200, data, "image/jpeg")
            return self._send(404, {"error": "not found"})
        except Exception as e:
            return self._send(500, {"error": "%s: %s" % (type(e).__name__, e)})

    def do_POST(self):
        u = urlparse(self.path)
        b = self._body()
        try:
            if u.path == "/api/pick":
                return self._send(200, {"path": pick_folder()})
            if u.path == "/api/scan":
                CTRL.start_scan(b.get("input", ""), int(b.get("workers") or CTRL.workers), b.get("strict", True) is not False)
            elif u.path == "/api/start":
                CTRL.start_run()
            elif u.path == "/api/pause":
                CTRL.pause()
            elif u.path == "/api/resume":
                CTRL.resume()
            elif u.path == "/api/stop":
                CTRL.stop()
            elif u.path == "/api/reports":
                CTRL.write_reports()
            elif u.path == "/api/open":
                open_in_explorer(CTRL.report_dir() if b.get("what") == "reports" else CTRL.inp)
            else:
                return self._send(404, {"error": "not found"})
            return self._send(200, {"ok": True})
        except ValueError as e:
            return self._send(400, {"error": str(e)})
        except Exception as e:
            return self._send(500, {"error": "%s: %s" % (type(e).__name__, e)})


def serve(open_browser=True):
    srv = None
    for port in range(8765, 8800):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            continue
    if srv is None:
        sys.exit("no free port between 8765 and 8799")
    url = "http://127.0.0.1:%d/" % port
    print("Yektasaz is running at:", url)
    print("The browser opens by itself; if it does not, type this address in the browser.")
    print("KEEP THIS WINDOW OPEN until the work is finished (closing it stops the program; the work resumes later).")
    print("یکتاساز اجرا شد؛ این پنجره را تا پایان کار نبندید.")
    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


# ------------------------------------------------------------------ console mode
def _fmt_time(sec):
    sec = int(sec or 0)
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m = r // 60
    return ("%dd " % d if d else "") + "%02d:%02d" % (h, m)


def run_cli(inp, workers, yes=False, strict=True):
    if not yes:
        print("همه‌ی PDFهای این پوشه روی خودشان بازنویسی می‌شوند و راه برگشت ندارد. برای ادامه --yes بدهید.")
        sys.exit(1)
    CTRL.start_scan(inp, workers, strict)
    while CTRL.phase in ("scanning", "counting", "calibrating"):
        s = CTRL.status()
        print("  %-12s found=%d counted=%d" % (s["phase"], s["found"], s.get("counted", 0)), flush=True)
        time.sleep(2)
    s = CTRL.status()
    if s["phase"] != "ready":
        sys.exit("stopped: %s %s" % (s["phase"], s["message"]))
    print("files=%d pages=%d  estimated time=%s  (%d workers)" % (s["files"], s["pages"], _fmt_time(s.get("eta")), CTRL.workers), flush=True)
    CTRL.start_run()
    while CTRL.phase in ("running", "paused", "stopping"):
        time.sleep(5)
        s = CTRL.status()
        print("  %d/%d files  removed pages=%d  very close=%d  problems=%d  left=%s" % (
            s["files_done"], s["files"], s["pages_removed"], s["near_pairs"], s["problems"], _fmt_time(s.get("eta"))), flush=True)
    s = CTRL.status()
    print("finished: %s  reports: %s" % (s["phase"], CTRL.report_dir()))


def main():
    mp.freeze_support()
    if "--selftest" in sys.argv:
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass
        import selftest
        sys.exit(selftest.run())
    for stream in (sys.stdout, sys.stderr):      # Persian text must never crash a redirected log
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if "--pick-folder" in sys.argv:
        return _pick_folder_child()
    ap = argparse.ArgumentParser(description="یکتاساز")
    ap.add_argument("--cli", metavar="FOLDER")
    ap.add_argument("--yes", action="store_true", help="confirm that files are rewritten in place")
    ap.add_argument("--balanced", action="store_true", help="balanced mode (default is strict: only practically identical pages are removed)")
    ap.add_argument("--selftest", action="store_true", help="check the whole program on generated test files")
    ap.add_argument("--workers", type=int, default=app_core.default_workers())
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    if a.cli:
        run_cli(a.cli, a.workers, a.yes, not a.balanced)
    else:
        serve(not a.no_browser)


if __name__ == "__main__":
    main()
