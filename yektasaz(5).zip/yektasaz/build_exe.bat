@echo off
setlocal enableextensions
cd /d "%~dp0"
title Build yektasaz.exe
echo ============================================================
echo  Build yektasaz.exe
echo  Run this on a Windows PC WITH internet (NOT on the offline server).
echo  Result: a self-contained folder to copy to the server.
echo ============================================================
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY goto nopython
%PY% -c "import sys; sys.exit(0 if (sys.maxsize>2**32 and sys.version_info>=(3,9)) else 1)" || goto badpython

if exist ".buildenv" rmdir /s /q ".buildenv"
%PY% -m venv .buildenv || goto fail
".buildenv\Scripts\python.exe" -m pip install --upgrade pip || goto fail
".buildenv\Scripts\python.exe" -m pip install -r requirements.txt pyinstaller || goto fail

rem Optional UI font. If the download fails nothing is lost: the UI uses Tahoma / Segoe UI.
if not exist fonts mkdir fonts
if not exist "fonts\Vazirmatn.woff2" (
  echo Downloading the Vazirmatn font ^(optional^)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "try{[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri 'https://cdn.jsdelivr.net/npm/vazirmatn@33.0.3/fonts/webfonts/Vazirmatn%%5Bwght%%5D.woff2' -OutFile 'fonts\Vazirmatn.woff2'}catch{}"
  powershell -NoProfile -Command "if((Test-Path 'fonts\Vazirmatn.woff2') -and ((Get-Item 'fonts\Vazirmatn.woff2').Length -lt 20000)){Remove-Item 'fonts\Vazirmatn.woff2'}"
)
if not exist "fonts\Vazirmatn.woff2" echo (font not downloaded: the UI will use Tahoma / Segoe UI)

if exist dist rmdir /s /q dist
if exist build rmdir /s /q build
".buildenv\Scripts\pyinstaller.exe" --noconfirm --clean --name yektasaz --console ^
  --add-data "ui.html;." --add-data "fonts;fonts" ^
  --collect-all pypdfium2 --collect-all pypdfium2_raw ^
  --hidden-import dedup_engine --hidden-import app_core --hidden-import selftest ^
  app.py || goto fail
if not exist "dist\yektasaz\yektasaz.exe" goto fail
copy /y README_FA.md "dist\yektasaz\" >nul

echo.
echo Build finished. Running the self-test now ^(about a minute^)...
"dist\yektasaz\yektasaz.exe" --selftest
if errorlevel 1 (
  echo.
  echo *** The self-test FAILED. Do not use this build. Send the text above for a fix. ***
  pause
  exit /b 1
)
powershell -NoProfile -Command "Compress-Archive -Path 'dist\yektasaz' -DestinationPath 'yektasaz_for_server.zip' -Force"
echo.
echo ============================================================
echo  READY.  Copy ONE of these to the server:
echo     dist\yektasaz\            ^(the folder^)
echo     yektasaz_for_server.zip   ^(the same folder, zipped^)
echo  On the server: double-click yektasaz.exe ^(no Python, no internet needed^)
echo  To verify on the server first:  yektasaz.exe --selftest
echo ============================================================
pause
exit /b 0

:nopython
echo Python 64-bit 3.9 or newer is required: https://www.python.org/downloads/windows/
echo (tick "Add python.exe to PATH" while installing)
pause
exit /b 1
:badpython
echo Python must be the 64-bit version 3.9 or newer.
pause
exit /b 1
:fail
echo.
echo *** Build failed. Check the messages above (internet connection?). ***
pause
exit /b 1
