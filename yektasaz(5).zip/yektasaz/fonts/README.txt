Optional: put Vazirmatn.woff2 in this folder and the interface will use the Vazirmatn font.
build_exe.bat tries to download it automatically; without it the interface uses Tahoma / Segoe UI.
