@echo off
rem Runs the program from source (needs Python + internet ONCE). On an offline server use yektasaz.exe instead.
cd /d "%~dp0"
if exist ".venv\installed.txt" goto run
echo First run: installing libraries...
if exist ".venv" rmdir /s /q ".venv"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY goto nopython
%PY% -m venv .venv || goto nopython
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto failed
echo ok> ".venv\installed.txt"
:run
".venv\Scripts\python.exe" app.py
pause
exit /b 0
:nopython
echo Python 3.12 (64-bit) is required: https://www.python.org/downloads/windows/
pause
exit /b 1
:failed
echo Installing libraries failed. Check the internet connection and run run.bat again.
pause
exit /b 1
