# -*- coding: utf-8 -*-
"""
Batch runner: inventory, time estimate, crash-proof parallel processing, resume, reports.

Safety rules
  * input files are only read, never modified
  * every PDF is analysed in a separate worker process with a time limit; a crash or hang of one
    file kills only that worker, the file is recorded as a problem and copied unchanged
  * all progress lives in an SQLite file inside the output folder, so a run can be stopped,
    closed or interrupted and later continued where it left off
"""
import atexit
import collections
import csv
import html as _html
import json
import multiprocessing as mp
import os
import random
import shutil
import sqlite3
import stat
import sys
import threading
import time
import traceback
from multiprocessing.connection import wait as mp_wait

APP_DIR_NAME = "_yektasaz"                # reports + state, created inside the output folder
DB_NAME = "state.sqlite"
EXCEL_ROWS = 1000000                      # split CSV reports so every part opens in Excel
DONE_STATES = ("done", "error", "encrypted", "timeout", "crash", "locked")
PROBLEM_STATES = ("error", "encrypted", "timeout", "crash", "locked")
RETRY_STATES = ("crash", "timeout", "locked")     # may have been transient: tried again next session
LOW_SPACE_MIN = 500 * 1024 * 1024         # below this much free disk the run pauses itself
NEAR_LABELS = {"text": "متن فرم تایپی فرق دارد",
               "marks": "مُهر، امضا، عدد یا نوشته‌ی اضافه",
               "crop": "برش یا بزرگ‌نمایی از صفحه‌ی دیگر",
               "similar": "تقریباً یکسان؛ به‌خاطر حالت سخت‌گیر حذف نشد"}
PROBLEM_LABELS = {"error": "خطا", "encrypted": "رمزدار", "timeout": "زمان تمام شد", "crash": "از کار افتادن",
                  "locked": "فایل باز یا قفل بود (دفعه‌ی بعد دوباره امتحان می‌شود)"}


class FolderBusy(ValueError):
    pass


def explain_error(msg):
    """Plain Persian explanation of a technical error text (None when unknown)."""
    m = (msg or "").lower()
    if "password" in m:
        return "فایل رمزدار است؛ بدون رمز بازشدنی نیست"
    if "data format" in m or "failed to load document" in m:
        return "فایل PDF خراب یا ناقص است و باز نمی‌شود"
    if "no space" in m or "errno 28" in m or "winerror 112" in m:
        return "فضای دیسک تمام شد"
    if "winerror 32" in m or "being used by another process" in m or "sharing violation" in m:
        return "فایل در برنامه‌ی دیگری باز است"
    if "permission" in m or "access is denied" in m or "winerror 5" in m or "replace:" in m:
        return "اجازه‌ی نوشتن روی فایل نبود (فقط‌خواندنی یا باز است)"
    if "does not match the original" in m or "looks different" in m or "wrong page count" in m:
        return "نسخه‌ی ساخته‌شده در بررسی با اصل نخواند؛ فایل اصلی دست نخورد"
    return None


def fmt_dur(sec):
    sec = int(max(0, sec or 0))
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m = r // 60
    if d:
        return "%d روز و %d ساعت" % (d, h)
    if h:
        return "%d ساعت و %d دقیقه" % (h, m)
    if m:
        return "%d دقیقه" % m
    return "کمتر از یک دقیقه"


def fmt_size(b):
    b = float(b or 0)
    if b >= 1e12:
        return "%.1f ترابایت" % (b / 1e12)
    if b >= 1e9:
        return "%.1f گیگابایت" % (b / 1e9)
    if b >= 1e6:
        return "%.0f مگابایت" % (b / 1e6)
    return "%.0f کیلوبایت" % (b / 1e3)


def default_workers():
    """All logical cores, but never more worker processes than the free memory can hold."""
    cpu = os.cpu_count() or 1
    free = _free_ram()
    if free:
        cpu = min(cpu, max(1, int((free - 1.5e9) / 0.6e9)))
    return max(1, cpu)


def _free_ram():
    try:
        if os.name == "nt":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("len", ctypes.c_ulong), ("load", ctypes.c_ulong), ("total", ctypes.c_ulonglong),
                            ("avail", ctypes.c_ulonglong), ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong),
                            ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong), ("ae", ctypes.c_ulonglong)]
            m = MS()
            m.len = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return float(m.avail)
        return float(os.sysconf("SC_AVPHYS_PAGES") * os.sysconf("SC_PAGE_SIZE"))
    except Exception:
        return None


# ============================================================ worker process side
TMP_SUFFIX = ".yekta-tmp"                 # new version is built next to the original, then swapped in


def _replace_file(target, new, st0):
    """Swap `new` in for `target` in one step. On Windows ReplaceFileW keeps the original's
    permissions (ACL), attributes and creation date. The modification date is kept too.
    A read-only original is made writable for the swap and set read-only again afterwards."""
    read_only = not (st0.st_mode & stat.S_IWRITE)
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.ReplaceFileW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.LPCWSTR,
                                     wintypes.DWORD, wintypes.LPVOID, wintypes.LPVOID]
        k32.ReplaceFileW.restype = wintypes.BOOL
        if read_only:
            os.chmod(target, stat.S_IREAD | stat.S_IWRITE)
        try:
            if not k32.ReplaceFileW(target, new, None, 0x2, None, None):    # 0x2: ignore merge errors
                raise ctypes.WinError(ctypes.get_last_error())
        except OSError:
            if read_only:
                os.chmod(target, stat.S_IREAD)
            raise
    else:
        os.chmod(new, st0.st_mode & 0o7777)
        os.replace(new, target)
    try:
        os.utime(target, (st0.st_atime, st0.st_mtime))
    except OSError:
        pass
    if read_only and os.name == "nt":
        try:
            os.chmod(target, stat.S_IREAD)
        except OSError:
            pass


def _cleanup(path):
    for p in (path + TMP_SUFFIX, path + TMP_SUFFIX + ".stage"):
        try:
            os.remove(p)
        except OSError:
            pass


def _process_one(E, job):
    """Analyse one PDF and rewrite it in place: duplicates removed, images at 150 dpi.
    The original is replaced only after the new file passed every check. With job['dry'] the
    new file is built and checked but thrown away (used for the time estimate)."""
    src, dry = job["src"], job.get("dry", False)
    t0 = time.time()
    out = {"fid": job["fid"], "kind": "process"}
    try:
        st0 = os.stat(src)
        res = E.analyze_pdf(src, strict=job.get("strict", True))
    except Exception as e:
        msg = "%s: %s" % (type(e).__name__, e)
        out.update(status="encrypted" if "password" in msg.lower() else "error", error=msg[:500],
                   out="untouched", secs=time.time() - t0)
        return out
    tmp = src + TMP_SUFFIX
    mode, note, size_out = "untouched", None, st0.st_size
    try:
        try:
            changed = E.write_output(src, res["keep"], tmp, compress=True)
            problem = E.verify_output(tmp, res["keep"], res["thumbs"])
            if problem:
                raise RuntimeError(problem)
            smaller = os.path.getsize(tmp) < st0.st_size
            if res["removed"] or (changed and smaller):
                mode = "compressed" if changed else "cleaned"
        except Exception as e:                      # compression failed a check: plain rewrite
            note = ("compression: %s: %s" % (type(e).__name__, e))[:300]
            _cleanup(src)
            if res["removed"]:
                E.write_output(src, res["keep"], tmp, compress=False)
                problem = E.verify_output(tmp, res["keep"], res["thumbs"])
                if problem:
                    raise RuntimeError("written file does not match the original pages: " + problem)
                mode = "cleaned-uncompressed"
        if mode != "untouched":
            size_out = os.path.getsize(tmp)
            if not dry:
                try:
                    _replace_file(src, tmp, st0)
                except OSError as e:                 # file in use / read-only: try again next session
                    out.update(status="locked", error=("replace: %s" % e)[:300], out="untouched",
                               secs=time.time() - t0)
                    return out
    except Exception as e:
        out.update(status="error", error=("output: %s: %s" % (type(e).__name__, e))[:500],
                   out="untouched", secs=time.time() - t0)
        return out
    finally:
        _cleanup(src)
    new_no = dict((k + 1, i + 1) for i, k in enumerate(res["keep"]))       # page numbers after rewrite
    if mode == "untouched":
        new_no = dict((k + 1, k + 1) for k in res["keep"])
    out.update(status="done", pages=res["pages"], kept=len(res["keep"]),
               removed=[(p, t, new_no.get(t, t), k, s) for p, t, k, s in res["removed"]],
               near=[(new_no[a], new_no[b], s, c, w) for a, b, s, c, w in res["near"]],
               mode=res["mode"], out=mode, secs=time.time() - t0, bytes_in=st0.st_size,
               bytes_out=size_out, note=note)
    return out


def worker_main(conn, engine_dir):
    if engine_dir not in sys.path:
        sys.path.insert(0, engine_dir)
    import dedup_engine as E
    while True:
        try:
            job = conn.recv()
        except (EOFError, OSError):
            return
        if job is None:
            return
        try:
            if job["kind"] == "count":
                items = []
                for fid, path in job["items"]:
                    try:
                        items.append((fid, E.count_pages(path), None))
                    except Exception as e:
                        items.append((fid, None, ("%s: %s" % (type(e).__name__, e))[:300]))
                conn.send({"kind": "count", "items": items})
            else:
                conn.send(_process_one(E, job))
        except Exception:
            conn.send({"kind": "fatal", "fid": job.get("fid"), "error": traceback.format_exc()[-800:]})


# ============================================================ worker pool (main process)
class _Worker(object):
    def __init__(self, ctx, engine_dir):
        self.conn, child = ctx.Pipe()
        self.proc = ctx.Process(target=worker_main, args=(child, engine_dir), daemon=True)
        self.proc.start()
        child.close()
        self.job, self.deadline, self.jobs_done = None, 0, 0

    def kill(self):
        try:
            self.proc.kill()
        except Exception:
            pass
        self.proc.join(5)
        try:
            self.conn.close()
        except Exception:
            pass


class Pool(object):
    """N worker processes. Each job has a deadline; dead or hung workers are replaced."""
    RECYCLE_AFTER = 400                    # fresh process every N files (keeps memory flat)

    def __init__(self, n):
        self.ctx = mp.get_context("spawn")
        self.engine_dir = os.path.dirname(os.path.abspath(__file__))
        self.workers = [_Worker(self.ctx, self.engine_dir) for _ in range(n)]

    def idle(self):
        return [w for w in self.workers if w.job is None]

    def busy(self):
        return [w for w in self.workers if w.job is not None]

    def submit(self, w, job, timeout):
        w.job, w.deadline = job, time.time() + timeout
        w.conn.send(job)

    def _replace(self, w):
        w.kill()
        i = self.workers.index(w)
        self.workers[i] = _Worker(self.ctx, self.engine_dir)

    def poll(self, timeout=0.25):
        """-> list of (job, result or None, failure) ; failure in (None, 'timeout', 'crash')."""
        out = []
        busy = self.busy()
        if not busy:
            time.sleep(timeout)
            return out
        ready = mp_wait([w.conn for w in busy], timeout)
        now = time.time()
        for w in busy:
            if w.conn in ready:
                try:
                    res = w.conn.recv()
                except (EOFError, OSError):
                    out.append((w.job, None, "crash"))
                    self._replace(w)
                    continue
                out.append((w.job, res, None))
                w.job = None
                w.jobs_done += 1
                if w.jobs_done >= self.RECYCLE_AFTER:
                    try:
                        w.conn.send(None)
                    except Exception:
                        pass
                    self._replace(w)
            elif not w.proc.is_alive():
                out.append((w.job, None, "crash"))
                self._replace(w)
            elif now > w.deadline:
                out.append((w.job, None, "timeout"))
                self._replace(w)
        return out

    def close(self):
        for w in self.workers:
            try:
                w.conn.send(None)
            except Exception:
                pass
        for w in self.workers:
            w.proc.join(3)
            if w.proc.is_alive():
                w.kill()


# ============================================================ state database
class Store(object):
    def __init__(self, path):
        self.db = sqlite3.connect(path, check_same_thread=False, timeout=60)
        self.lock = threading.RLock()
        with self.lock:
            c = self.db
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            c.executescript("""
            CREATE TABLE IF NOT EXISTS files(
              id INTEGER PRIMARY KEY, rel TEXT UNIQUE, size INTEGER, mtime REAL,
              pages INTEGER, status TEXT DEFAULT 'new', kept INTEGER, removed INTEGER DEFAULT 0,
              near INTEGER DEFAULT 0, secs REAL, out TEXT, error TEXT, mode TEXT);
            CREATE INDEX IF NOT EXISTS ix_files_status ON files(status);
            CREATE TABLE IF NOT EXISTS removed(fid INTEGER, page INTEGER, twin INTEGER, kind TEXT, score INTEGER);
            CREATE INDEX IF NOT EXISTS ix_removed_fid ON removed(fid);
            CREATE TABLE IF NOT EXISTS near(fid INTEGER, pa INTEGER, pb INTEGER, score INTEGER, cover REAL);
            CREATE INDEX IF NOT EXISTS ix_near_fid ON near(fid);
            CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);
            """)
            cols = [r[1] for r in c.execute("PRAGMA table_info(files)")]
            if "bytes_out" not in cols:
                c.execute("ALTER TABLE files ADD COLUMN bytes_out INTEGER")
            if "note" not in cols:
                c.execute("ALTER TABLE files ADD COLUMN note TEXT")
            if "bytes_in" not in cols:
                c.execute("ALTER TABLE files ADD COLUMN bytes_in INTEGER")
            if "twin_new" not in [r[1] for r in c.execute("PRAGMA table_info(removed)")]:
                c.execute("ALTER TABLE removed ADD COLUMN twin_new INTEGER")
            if "reason" not in [r[1] for r in c.execute("PRAGMA table_info(near)")]:
                c.execute("ALTER TABLE near ADD COLUMN reason TEXT")
            c.execute("UPDATE files SET status='counted' WHERE status='running' AND pages IS NOT NULL")
            c.execute("UPDATE files SET status='new' WHERE status='running'")
            c.commit()

    def q(self, sql, args=()):
        with self.lock:
            return self.db.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        r = self.q(sql, args)
        return r[0] if r else None

    def get_meta(self, k, default=None):
        r = self.one("SELECT v FROM meta WHERE k=?", (k,))
        return r[0] if r else default

    def set_meta(self, k, v):
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO meta(k,v) VALUES(?,?)", (k, str(v)))
            self.db.commit()


# ============================================================ controller
class Controller(object):
    """Drives one input->output job. All public methods are thread-safe and non-blocking."""

    def __init__(self):
        self.lock = threading.RLock()
        self.phase = "idle"
        self.message = ""
        self.store = None
        self.inp = self.out = None
        self.workers = default_workers()
        self.strict = True                    # strict is the default: a wrong removal cannot be undone
        self._last_commit = 0.0
        self.thread = None
        self.pause_evt = threading.Event()
        self.stop_evt = threading.Event()
        self.recent = []
        self.problems = []
        self.found = 0
        self.est = {}
        self.rate_win = []                    # (time, pages) samples for live speed
        self.run_started = None
        self.job_timeout_base = 120.0
        self.job_timeout_per_page = 4.0
        self.c = {}
        self.counted = 0
        self.events = collections.deque(maxlen=5000)     # live log shown in the UI
        self._seq = 0
        self._ev_lock = threading.Lock()
        self.alert_counts = {}
        self._log_fp = None
        self.free_bytes = None
        self.low_space = False
        self._need = LOW_SPACE_MIN
        self._n_sub = 0
        self._last_hb = 0.0
        self._lock_alive = False
        atexit.register(self._release_lock)

    # ---------------------------------------------------------------- live log / alerts
    def _log(self, lvl, msg, file=None, kind=None, to_file=True):
        """lvl: info | ok | dim | warn | error.  kind marks an alert: something the user must look at."""
        with self._ev_lock:
            self._seq += 1
            ev = {"n": self._seq, "t": time.time(), "lvl": lvl, "msg": msg}
            if file:
                ev["file"] = file
            if kind:
                ev["kind"] = kind
                self.alert_counts[kind] = self.alert_counts.get(kind, 0) + 1
            self.events.append(ev)
            fp = self._log_fp
        if fp is not None and to_file:
            try:
                fp.write("%s [%s] %s%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), lvl.upper(), msg,
                                              (" | " + file) if file else ""))
                fp.flush()
            except Exception:
                pass

    def events_since(self, since, limit=400):
        with self._ev_lock:
            evs = [e for e in self.events if e["n"] > since]
        return evs[-limit:]

    def _open_log(self):
        try:
            if self._log_fp is not None:
                self._log_fp.close()
        except Exception:
            pass
        try:
            self._log_fp = open(os.path.join(self.report_dir(), "log.txt"), "a", encoding="utf-8")
        except OSError:
            self._log_fp = None

    # ---------------------------------------------------------------- one program per folder
    def _lock_file(self):
        return os.path.join(self.report_dir(), "running.lock")

    def _write_lock(self):
        try:
            with open(self._lock_file(), "w", encoding="utf-8") as f:
                json.dump({"pid": os.getpid(), "t": time.time()}, f)
        except OSError:
            pass

    def _acquire_lock(self):
        try:
            with open(self._lock_file(), "r", encoding="utf-8") as f:
                d = json.load(f)
            if time.time() - float(d.get("t", 0)) < 45 and d.get("pid") != os.getpid():
                raise FolderBusy("این پوشه همین حالا در برنامه‌ی دیگری (یا پنجره‌ی دیگری) در حال کار است")
        except FolderBusy:
            raise
        except Exception:
            pass                                  # no lock, unreadable lock or a stale one
        self._write_lock()
        if not self._lock_alive:
            self._lock_alive = True
            threading.Thread(target=self._lock_loop, daemon=True).start()

    def _lock_loop(self):
        while self._lock_alive:
            time.sleep(10)
            if self._lock_alive:
                self._write_lock()

    def _release_lock(self):
        if self._lock_alive:
            self._lock_alive = False
            try:
                os.remove(self._lock_file())
            except Exception:
                pass

    # ---------------------------------------------------------------- disk space
    def _space_need(self):
        big = [r[0] or 0 for r in self.store.q("SELECT size FROM files ORDER BY size DESC LIMIT ?", (max(1, self.workers),))]
        return max(LOW_SPACE_MIN, int(2.2 * sum(big)))          # temp copy + staging copy per worker

    def _check_space(self, initial=False):
        try:
            free = shutil.disk_usage(self.inp).free
        except OSError:
            return True
        self.free_bytes = free
        need = self._space_need()
        self.low_space = free < need
        if self.low_space:
            self._log("error", "فضای آزاد دیسک کم است: %s آزاد، دست‌کم %s لازم است. اول فضا آزاد کنید." % (fmt_size(free), fmt_size(need)), kind="space")
        elif initial:
            self._log("info", "فضای آزاد دیسک: %s (کافی است)" % fmt_size(free))
        return not self.low_space

    # ---------------------------------------------------------------- public API
    def start_scan(self, inp, workers, strict=True):
        inp = os.path.abspath(inp)
        if not os.path.isdir(inp):
            raise ValueError("پوشه پیدا نشد")
        with self.lock:
            if self.phase in ("scanning", "counting", "calibrating", "running", "stopping"):
                raise ValueError("یک کار در حال اجراست")
            os.makedirs(os.path.join(inp, APP_DIR_NAME), exist_ok=True)
            self.inp = self.out = inp            # files are rewritten where they are
            self._acquire_lock()
            self.workers = max(1, int(workers))
            self.strict = bool(strict)
            if self.store is None or self.store_path() != getattr(self, "_store_path", None):
                self.store = Store(self.store_path())
                self._store_path = self.store_path()
                self._refresh_counts()
            self.store.set_meta("input", inp)
            self.store.set_meta("strict", "1" if self.strict else "0")
            self._open_log()
            self.stop_evt.clear()
            self.pause_evt.clear()
            self.phase, self.message, self.found, self.est = "scanning", "", 0, {}
            self.low_space = False
            self._log("info", "بررسی پوشه شروع شد (حالت %s، %d هسته)" % ("سخت‌گیر" if self.strict else "متعادل", self.workers), file=inp)
            self.thread = threading.Thread(target=self._guard, args=(self._scan_and_estimate,), daemon=True)
            self.thread.start()

    def start_run(self):
        with self.lock:
            if self.phase not in ("ready", "stopped", "finished"):
                raise ValueError("اول باید پوشه‌ها بررسی شوند")
            self.stop_evt.clear()
            self.pause_evt.clear()
            self.phase = "running"
            self.thread = threading.Thread(target=self._guard, args=(self._run,), daemon=True)
            self.thread.start()

    def pause(self):
        if self.phase == "running":
            self.pause_evt.set()
            self.phase = "paused"
            self._log("warn", "کار مکث شد (فایل‌هایی که در حال پردازش‌اند تمام می‌شوند)")

    def resume(self):
        if self.phase == "paused":
            self.pause_evt.clear()
            self.phase = "running"
            self._log("info", "کار ادامه پیدا کرد")

    def stop(self):
        if self.phase in ("scanning", "counting", "calibrating", "running", "paused"):
            self.stop_evt.set()
            self.pause_evt.clear()
            self.phase = "stopping"
            self._log("warn", "درخواست توقف داده شد؛ فایل‌های در حال پردازش تمام می‌شوند")

    def store_path(self):
        return os.path.join(self.out, APP_DIR_NAME, DB_NAME)

    def report_dir(self):
        return os.path.join(self.out, APP_DIR_NAME)

    # ---------------------------------------------------------------- status for the UI
    def status(self):
        s = {"phase": self.phase, "message": self.message, "input": self.inp, "output": self.out,
             "workers": self.workers, "cpu": os.cpu_count() or 1, "default_workers": default_workers(),
             "found": self.found, "est": self.est, "counted": self.counted,
             "strict": self.strict, "free_bytes": self.free_bytes, "low_space": self.low_space,
             "seq": self._seq, "alerts": dict(self.alert_counts)}
        active = 0.0
        if self.store is not None:
            with self.lock:
                s.update(self.c)
            rate = self._live_rate()
            left = max(0, s["pages"] - s["pages_done"])
            if rate:
                s["rate"] = rate
                s["eta"] = left / rate
            elif self.est.get("rate"):
                s["eta"] = left / self.est["rate"]
            try:
                active = float(self.store.get_meta("active_secs", 0) or 0)
            except Exception:
                active = 0.0
        if self.run_started and self.phase in ("running", "paused", "stopping"):
            active += time.time() - self.run_started
        s["active_secs"] = active
        s["recent"] = list(self.recent[-14:])
        s["problem_list"] = list(self.problems[-30:])
        s["elapsed"] = (time.time() - self.run_started) if self.run_started and self.phase in ("running", "paused") else None
        return s

    def _refresh_counts(self):
        st = self.store
        if st is not None:
            r = st.one("""SELECT COUNT(*), COALESCE(SUM(pages),0), COALESCE(SUM(size),0),
                          SUM(status IN ('done','error','encrypted','timeout','crash','locked')),
                          COALESCE(SUM(CASE WHEN status IN ('done','error','encrypted','timeout','crash','locked') THEN pages END),0),
                          COALESCE(SUM(removed),0), COALESCE(SUM(near),0),
                          SUM(status IN ('error','encrypted','timeout','crash','locked')),
                          SUM(removed>0), SUM(pages IS NULL AND status='new'),
                          COALESCE(SUM(bytes_in),0), COALESCE(SUM(bytes_out),0)
                          FROM files""")
            with self.lock:
                self.c = dict(files=r[0] or 0, pages=r[1] or 0, bytes=r[2] or 0, files_done=r[3] or 0,
                              pages_done=r[4] or 0, pages_removed=r[5] or 0, near_pairs=r[6] or 0,
                              problems=r[7] or 0, files_cleaned=r[8] or 0, uncounted=r[9] or 0,
                              bytes_in_done=r[10] or 0, bytes_out=r[11] or 0)

    def _bump(self, **kw):
        with self.lock:
            for k, v in kw.items():
                self.c[k] = self.c.get(k, 0) + v

    def _live_rate(self):
        w = [x for x in self.rate_win if time.time() - x[0] < 300]
        self.rate_win = w
        if len(w) < 2 or w[-1][0] - w[0][0] < 5:
            return None
        return sum(p for _, p in w[1:]) / (w[-1][0] - w[0][0])

    # ---------------------------------------------------------------- phases
    def _guard(self, fn):
        try:
            fn()
        except Exception as e:
            self.message = "%s: %s" % (type(e).__name__, e)
            self.phase = "error"
            traceback.print_exc()

    def _walk(self):
        root = _long_path(self.inp, force=True)
        skip = os.path.normcase(os.path.join(root, APP_DIR_NAME))
        stack = [root]
        while stack:
            if self.stop_evt.is_set():
                return
            d = stack.pop()
            try:
                it = os.scandir(d)
            except OSError as e:
                self._problem(os.path.relpath(d, root), "error", "پوشه خوانده نشد: %s" % e)
                continue
            with it:
                for e in it:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            if os.path.normcase(e.path) != skip:
                                stack.append(e.path)
                        elif e.is_file(follow_symlinks=False) and (e.name.endswith(TMP_SUFFIX) or
                                                                   e.name.endswith(TMP_SUFFIX + ".stage")):
                            try:
                                os.remove(e.path)            # half-built file of an interrupted run
                            except OSError:
                                pass
                        elif e.is_file(follow_symlinks=False) and e.name.lower().endswith(".pdf"):
                            st = e.stat(follow_symlinks=False)
                            yield os.path.relpath(e.path, root).replace(os.sep, "/"), st.st_size, st.st_mtime
                    except OSError:
                        continue

    def _scan_and_estimate(self):
        st = self.store
        # 1) inventory
        batch = []
        self._log("info", "در حال پیدا کردن فایل‌های PDF…")

        def flush():
            with st.lock:
                cur = st.db.cursor()
                for rel, size, mtime in batch:
                    row = cur.execute("SELECT id,size,mtime FROM files WHERE rel=?", (rel,)).fetchone()
                    if row is None:
                        cur.execute("INSERT INTO files(rel,size,mtime) VALUES(?,?,?)", (rel, size, mtime))
                    elif row[1] != size or abs((row[2] or 0) - mtime) > 1:
                        cur.execute("""UPDATE files SET size=?,mtime=?,pages=NULL,status='new',kept=NULL,
                                       removed=0,near=0,secs=NULL,out=NULL,error=NULL WHERE id=?""", (size, mtime, row[0]))
                        cur.execute("DELETE FROM removed WHERE fid=?", (row[0],))
                        cur.execute("DELETE FROM near WHERE fid=?", (row[0],))
                st.db.commit()
            del batch[:]

        for item in self._walk():
            batch.append(item)
            self.found += 1
            if len(batch) >= 2000:
                flush()
        flush()
        with st.lock:                      # a crash/timeout may have been transient: try once more
            st.db.execute("UPDATE files SET status='counted', error=NULL WHERE status IN ('crash','timeout','locked')")
            st.db.execute("UPDATE files SET status='counted' WHERE status='done' AND bytes_out IS NULL")
            st.db.commit()
        self._refresh_counts()
        self._log("info", "%d فایل PDF پیدا شد (%s)" % (self.c.get("files", 0), fmt_size(self.c.get("bytes", 0))))
        if self.stop_evt.is_set():
            self.phase = "stopped"
            return

        # 2) page counts (in workers: a broken PDF must not take the app down)
        self.phase = "counting"
        self._log("info", "شمارش صفحه‌ها شروع شد")
        pool = Pool(self.workers)
        try:
            self._count_pages(pool)
            if self.stop_evt.is_set():
                self.phase = "stopped"
                self._log("warn", "بررسی پوشه متوقف شد")
                return
            self._refresh_counts()
            self._log("info", "شمارش تمام شد: %d صفحه در %d فایل" % (self.c.get("pages", 0), self.c.get("files", 0)))
            # 3) time estimate from a real sample (nothing is changed: the new files are thrown away)
            self.phase = "calibrating"
            self._log("info", "سنجش سرعت روی چند فایل واقعی (هیچ فایلی تغییر نمی‌کند)")
            self._calibrate(pool)
        finally:
            pool.close()
        self._refresh_counts()
        if self.stop_evt.is_set():
            self.phase = "stopped"
            return
        self._check_space(initial=True)
        self._log_estimate()
        if not self.store.one("SELECT 1 FROM files WHERE status IN ('new','counted') LIMIT 1"):
            self._log("ok", "همه‌ی فایل‌ها قبلاً پردازش شده‌اند")
            self.write_reports()
            self.phase = "finished"
            self._release_lock()
        else:
            self._log("ok", "آماده‌ی شروع است؛ تیک تأیید را بزنید و «شروع پاکسازی» را بزنید")
            self.phase = "ready"

    def _log_estimate(self):
        e = self.est or {}
        left = max(0, self.c.get("pages", 0) - self.c.get("pages_done", 0))
        if e.get("rate"):
            self._log("ok", "تخمین زمان: %s برای %d صفحه (حدود %.1f صفحه در ثانیه با %d هسته)" % (
                fmt_dur(left / e["rate"]), left, e["rate"], self.workers))
            if e.get("size_ratio"):
                self._log("info", "حجم پس از کار حدود %s می‌شود (اکنون %s)" % (
                    fmt_size(self.c.get("bytes", 0) * e["size_ratio"]), fmt_size(self.c.get("bytes", 0))))
        else:
            self._log("warn", "سرعت تخمین زده نشد؛ زمان باقی‌مانده بعد از شروع کار نشان داده می‌شود")

    def _count_pages(self, pool):
        st = self.store
        todo = [r for r in st.q("SELECT id, rel FROM files WHERE pages IS NULL AND status='new' ORDER BY id")]
        self.counted = 0
        queue = [todo[i:i + 40] for i in range(0, len(todo), 40)]
        singles = []
        while (queue or singles or pool.busy()) and not self.stop_evt.is_set():
            for w in pool.idle():
                if singles:
                    items = [singles.pop()]
                elif queue:
                    items = queue.pop()
                else:
                    break
                job = {"kind": "count", "items": [(fid, self._abs(rel)) for fid, rel in items], "rels": items}
                pool.submit(w, job, 30 + 3 * len(items))
            for job, res, fail in pool.poll():
                if fail:
                    if len(job["rels"]) > 1:
                        singles.extend(job["rels"])
                    else:
                        fid = job["items"][0][0]
                        self._set_count(fid, None, "هنگام خواندن فایل %s" % ("زمان تمام شد" if fail == "timeout" else "برنامه‌ی کمکی از کار افتاد"))
                    continue
                for fid, pages, err in res.get("items", []):
                    self._set_count(fid, pages, err)
            self._commit(False)
        self._commit(True)

    def _set_count(self, fid, pages, err):
        st = self.store
        self.counted += 1
        with st.lock:
            if pages is None:
                st.db.execute("UPDATE files SET pages=0, status='counted', error=? WHERE id=?", (err, fid))
            else:
                st.db.execute("UPDATE files SET pages=?, status='counted' WHERE id=?", (pages, fid))

    def _calibrate(self, pool):
        st = self.store
        n = min(max(6, 3 * self.workers), 40)
        top = st.one("SELECT COALESCE(MAX(id),0) FROM files")[0]
        rows, seen = [], set()
        rng = random.Random(7)
        for _ in range(n * 4):
            if len(rows) >= n or not top:
                break
            r = st.one("""SELECT id, rel, pages, size FROM files WHERE id>=? AND status='counted' AND pages>0
                          ORDER BY id LIMIT 1""", (rng.randint(1, top),))
            if r and r[0] not in seen:
                seen.add(r[0])
                rows.append(r)
        if not rows:
            done = st.one("SELECT COALESCE(SUM(pages),0), COALESCE(SUM(secs),0) FROM files WHERE status='done'")
            if done and done[0] and done[1]:
                self.est = {"rate": done[0] / done[1] * self.workers, "sample_files": 0}
            return
        self._cal = []
        pages = self._process_rows(pool, rows, calibrating=True)
        cal = [r for r in self._cal if r.get("status") == "done"]
        cpu = sum(r["secs"] for r in cal)
        pages = sum(r["pages"] for r in cal)
        rate = pages / max(cpu / float(self.workers), 1e-3) if cpu else None
        bi = sum(r["bytes_in"] for r in cal)
        bo = sum(r["bytes_out"] for r in cal)
        self.est = {"rate": rate, "sample_files": len(cal), "sample_pages": pages,
                    "sec_per_page": (cpu / pages) if pages else None,
                    "size_ratio": (bo / float(bi)) if bi else None}

    def _run(self):
        self.run_started = time.time()
        left = self.store.one("SELECT COUNT(*), COALESCE(SUM(pages),0) FROM files WHERE status IN ('new','counted')")
        self._need = self._space_need()
        self._last_hb = time.time()
        self._log("ok", "پاکسازی شروع شد: %d فایل (%d صفحه) با %d هسته، حالت %s" % (
            left[0], left[1], self.workers, "سخت‌گیر" if self.strict else "متعادل"))
        pool = Pool(self.workers)
        try:
            last = 0
            while not self.stop_evt.is_set():
                rows = self.store.q("""SELECT id, rel, pages, size FROM files WHERE id>? AND status IN ('new','counted')
                                       ORDER BY id LIMIT 500""", (last,))
                if not rows:
                    break
                last = rows[-1][0]
                rows.sort(key=lambda r: -(r[2] or 0))      # big files first: no idle cores at the end
                self._process_rows(pool, rows)
        finally:
            pool.close()
            self._flush_active_time()
        self._refresh_counts()
        self.write_reports()
        if self.stop_evt.is_set():
            self.phase = "stopped"
            self._log("warn", "کار متوقف شد؛ همین پوشه را دوباره بررسی کنید تا از همین‌جا ادامه پیدا کند")
        else:
            self.phase = "finished"
            self._log_finish()
            self._release_lock()

    def _flush_active_time(self):
        if self.run_started:
            try:
                prev = float(self.store.get_meta("active_secs", 0) or 0)
                self.store.set_meta("active_secs", prev + time.time() - self.run_started)
            except Exception:
                pass
            self.run_started = None

    def _log_finish(self):
        c = self.c
        self._log("ok", "تمام شد: %d فایل پردازش شد، %d صفحه‌ی تکراری حذف شد، حجم %s ← %s" % (
            c.get("files_done", 0), c.get("pages_removed", 0), fmt_size(c.get("bytes_in_done", 0)), fmt_size(c.get("bytes_out", 0))))
        if c.get("near_pairs"):
            self._log("warn", "%d جفت صفحه‌ی خیلی نزدیک برای بررسی شما نگه داشته شده است" % c["near_pairs"])
        if c.get("problems"):
            self._log("warn", "%d فایل دست‌نخورده ماند (خراب، رمزدار، قفل یا کند)؛ فهرستش در «فایل‌های مشکل‌دار» است" % c["problems"])

    def _heartbeat(self):
        c = self.c
        rate = self._live_rate()
        left = max(0, c.get("pages", 0) - c.get("pages_done", 0))
        tail = (" — زمان باقی‌مانده حدود %s (%.1f صفحه در ثانیه)" % (fmt_dur(left / rate), rate)) if rate else ""
        self._log("info", "پیشرفت: %d از %d فایل%s" % (c.get("files_done", 0), c.get("files", 0), tail))

    def _space_ok_now(self):
        try:
            free = shutil.disk_usage(self.inp).free
        except OSError:
            return True
        self.free_bytes = free
        return free >= self._need

    def _process_rows(self, pool, rows, calibrating=False):
        queue = list(reversed(rows))
        pages_done = 0
        while (queue or pool.busy()) and not self.stop_evt.is_set():
            if not calibrating and time.time() - self._last_hb > 60:
                self._last_hb = time.time()
                self._heartbeat()
            if not self.pause_evt.is_set():
                for w in pool.idle():
                    if not queue:
                        break
                    item = queue.pop()
                    if not calibrating:
                        self._n_sub += 1
                        if self._n_sub % 40 == 0 and not self._space_ok_now():
                            queue.append(item)             # not started: it stays for after the pause
                            self.pause_evt.set()
                            self.phase = "paused"
                            self.low_space = True
                            self._log("error", "فضای آزاد دیسک به %s رسید؛ کار خودکار مکث شد. فضا آزاد کنید و «ادامه» را بزنید." % fmt_size(self.free_bytes), kind="space")
                            break
                    fid, rel, pages, size = item
                    job = {"kind": "process", "fid": fid, "rel": rel, "src": self._abs(rel), "strict": self.strict,
                           "dry": calibrating, "pages": pages or 0, "size": size or 0}
                    tmo = min(3600.0, self.job_timeout_base + self.job_timeout_per_page * (pages or 150))
                    pool.submit(w, job, tmo)
            for job, res, fail in pool.poll():
                if calibrating:
                    if res and not fail:
                        self._cal.append(res)
                    continue
                pages_done += self._record(job, res, fail)
            self._commit(False)
        self._commit(True)
        grace = time.time() + 45
        while self.stop_evt.is_set() and pool.busy() and time.time() < grace:
            for job, res, fail in pool.poll():
                if fail != "timeout" and not calibrating:
                    pages_done += self._record(job, res, fail)
        self._commit(True)
        return pages_done

    def _commit(self, force):
        """Results are committed in batches (every ~0.5 s) so many cores never wait on the database."""
        if force or time.time() - self._last_commit > 0.5:
            with self.store.lock:
                self.store.db.commit()
            self._last_commit = time.time()

    # ---------------------------------------------------------------- results
    def _record(self, job, res, fail):
        st = self.store
        fid, rel = job["fid"], job["rel"]
        if fail or res is None or res.get("kind") == "fatal":
            status = fail or "error"
            msg = {"timeout": "پردازش بیش از حد طول کشید و متوقف شد",
                   "crash": "فایل باعث از کار افتادن برنامه‌ی کمکی شد"}.get(status, (res or {}).get("error", ""))
            try:
                _cleanup(job["src"])                  # half-built file of the killed worker
            except Exception:
                pass
            with st.lock:
                st.db.execute("UPDATE files SET status=?, error=?, out='untouched', bytes_in=size, bytes_out=size WHERE id=?",
                              (status, msg, fid))
            self._bump(files_done=1, pages_done=job.get("pages") or 0, problems=1,
                       bytes_in_done=job.get("size") or 0, bytes_out=job.get("size") or 0)
            self._problem(rel, status, msg)
            return 0
        status = res["status"]
        with st.lock:
            if status == "done":
                st.db.execute("DELETE FROM removed WHERE fid=?", (fid,))
                st.db.execute("DELETE FROM near WHERE fid=?", (fid,))
                st.db.executemany("INSERT INTO removed(fid,page,twin,twin_new,kind,score) VALUES(?,?,?,?,?,?)",
                                  [(fid, p, t, tn, k, int(s)) for p, t, tn, k, s in res["removed"]])
                st.db.executemany("INSERT INTO near(fid,pa,pb,score,cover,reason) VALUES(?,?,?,?,?,?)",
                                  [(fid, a, b, int(s), float(c), w) for a, b, s, c, w in res["near"]])
                # size/pages of the rewritten file, so a later scan sees it as already done
                st.db.execute("""UPDATE files SET status='done', pages=?, kept=?, removed=?, near=?, secs=?,
                                 out=?, mode=?, error=NULL, bytes_in=?, bytes_out=?, size=?, note=? WHERE id=?""",
                              (res["pages"], res["kept"], len(res["removed"]), len(res["near"]), res["secs"],
                               res["out"], res["mode"], res["bytes_in"], res["bytes_out"], res["bytes_out"],
                               res.get("note"), fid))
            else:
                st.db.execute("UPDATE files SET status=?, error=?, secs=?, out='untouched', bytes_in=size, bytes_out=size WHERE id=?",
                              (status, res.get("error"), res.get("secs"), fid))
        if status != "done":
            self._bump(files_done=1, pages_done=job.get("pages") or 0, problems=1,
                       bytes_in_done=job.get("size") or 0, bytes_out=job.get("size") or 0)
            self._problem(rel, status, res.get("error", ""))
            return 0
        self._bump(files_done=1, pages_done=res["pages"], pages_removed=len(res["removed"]),
                   near_pairs=len(res["near"]), files_cleaned=1 if res["removed"] else 0,
                   pages=res["pages"] - (job.get("pages") or 0),
                   bytes_in_done=res["bytes_in"], bytes_out=res["bytes_out"])
        self.rate_win.append((time.time(), res["pages"]))
        self.recent.append({"file": rel, "pages": res["pages"], "kept": res["kept"],
                            "removed": len(res["removed"]), "near": len(res["near"]),
                            "secs": round(res["secs"], 1)})
        del self.recent[:-40]
        rem, near = len(res["removed"]), len(res["near"])
        b_in, b_out = res["bytes_in"], res["bytes_out"]
        if rem:
            self._log("ok", "%d صفحه‌ی تکراری حذف شد (%d ← %d صفحه)؛ حجم %s ← %s" % (
                rem, res["pages"], res["kept"], fmt_size(b_in), fmt_size(b_out)), file=rel)
        elif res["out"] == "compressed":
            self._log("dim", "فشرده شد: %s ← %s" % (fmt_size(b_in), fmt_size(b_out)), file=rel, to_file=False)
        else:
            self._log("dim", "بدون تغییر (تکراری نداشت و فشرده‌سازی سودی نداشت)", file=rel, to_file=False)
        if near:
            top = min(res["near"], key=lambda x: x[2])
            self._log("warn", "%d جفت صفحه‌ی خیلی نزدیک؛ حذف نشدند و باید بررسی شوند (نزدیک‌ترین: صفحه‌ی %d و %d)" % (
                near, top[0], top[1]), file=rel, kind="near")
        if res.get("note"):
            self._log("warn", "فشرده‌سازی این فایل در بررسی رد شد؛ فایل بدون فشرده‌سازی ذخیره شد", file=rel, kind="compress")
        if res.get("mode") in ("exact-only", "capped"):
            self._log("warn", "فایل خیلی بزرگ است؛ %s" % ("فقط کپی‌های دقیق بررسی شد" if res["mode"] == "exact-only"
                                                          else "فقط بخشی از مقایسه‌ها انجام شد"), file=rel, kind="limit")
        return res["pages"]

    def _problem(self, rel, status, msg):
        self.problems.append({"file": rel, "status": status, "error": msg})
        del self.problems[:-200]
        self._log("warn" if status == "locked" else "error",
                  "%s%s" % (PROBLEM_LABELS.get(status, status), (": " + (explain_error(msg) or str(msg)[:200])) if msg else ""),
                  file=rel, kind="problem")

    def _abs(self, rel):
        return _long_path(os.path.join(self.inp, rel.replace("/", os.sep)))

    # ---------------------------------------------------------------- reports
    def write_reports(self):
        st, d = self.store, self.report_dir()
        if st is None:
            return
        os.makedirs(d, exist_ok=True)
        with st.lock:
            self._write_reports(st, d)

    def _write_reports(self, st, d):
        kinds = {"exact": "کاملاً یکسان", "same": "همان برگه (اسکن یا عکس دوباره)"}
        _csv_parts(d, "removed_pages", ["فایل", "صفحه‌ی حذف‌شده (شماره در فایل قبل از کار)",
                                        "تکراریِ صفحه‌ی (شماره در فایل فعلی)", "نوع", "امتیاز تفاوت"],
                   ((r[0], r[1], r[2], kinds.get(r[3], r[3]), r[4]) for r in st.db.execute(
                       """SELECT f.rel, r.page, COALESCE(r.twin_new, r.twin), r.kind, r.score
                          FROM removed r JOIN files f ON f.id=r.fid ORDER BY f.id, r.page""")))
        _csv_parts(d, "very_close_pages", ["فایل", "صفحه (شماره در فایل فعلی)", "صفحه (شماره در فایل فعلی)", "علت نگه داشتن",
                                           "امتیاز تفاوت (کمتر = نزدیک‌تر)", "درصد هم‌پوشانی", "وضعیت"],
                   ((r[0], r[1], r[2], NEAR_LABELS.get(r[5], "—"), r[3], int(round(r[4] * 100)), "نگه داشته شد؛ بررسی شود")
                    for r in st.db.execute(
                        "SELECT f.rel, n.pa, n.pb, n.score, n.cover, n.reason FROM near n JOIN files f ON f.id=n.fid ORDER BY n.score, f.id")))
        _csv_parts(d, "problems", ["فایل", "مشکل", "توضیح", "خروجی"],
                   ((r[0], "فشرده نشد" if r[1] == "done" else PROBLEM_LABELS.get(r[1], r[1]), r[2] if r[1] != "done" else r[4], r[3])
                    for r in st.db.execute("""SELECT rel, status, error, out, note FROM files
                        WHERE status IN ('error','encrypted','timeout','crash','locked') OR note IS NOT NULL ORDER BY id""")))
        s = self.status()
        bi, bo = s.get("bytes_in_done", 0), s.get("bytes_out", 0)
        with open(os.path.join(d, "summary.txt"), "w", encoding="utf-8-sig") as f:
            f.write("پوشه: %s (فایل‌ها روی خودشان بازنویسی شدند)\n" % self.inp)
            f.write("حالت: %s\n" % ("سخت‌گیر" if self.strict else "متعادل"))
            f.write("فایل‌ها: %d  (پردازش‌شده: %d)\n" % (s.get("files", 0), s.get("files_done", 0)))
            f.write("صفحه‌ها: %d  حذف‌شده: %d\n" % (s.get("pages", 0), s.get("pages_removed", 0)))
            f.write("فایل‌های پاکسازی‌شده: %d\n" % s.get("files_cleaned", 0))
            f.write("جفت‌صفحه‌های خیلی نزدیک (بررسی شوند): %d\n" % s.get("near_pairs", 0))
            f.write("فایل‌های مشکل‌دار: %d\n" % s.get("problems", 0))
            if bi:
                f.write("حجم پیش از کار: %s  پس از کار: %s  (%d%% کمتر)\n" % (fmt_size(bi), fmt_size(bo), round(100 - 100.0 * bo / bi)))
            f.write("زمان کار: %s\n" % fmt_dur(s.get("active_secs", 0)))
            nc = st.one("SELECT COUNT(*) FROM files WHERE note IS NOT NULL")[0]
            f.write("فایل‌هایی که فشرده‌سازی‌شان در بررسی رد شد و بدون فشرده‌سازی ذخیره شدند: %d (در problems.csv)\n" % nc)
        try:
            self._write_report_html(st, d, s)
        except Exception:
            traceback.print_exc()

    def _write_report_html(self, st, d, s):
        e = _html.escape
        bi, bo = s.get("bytes_in_done", 0), s.get("bytes_out", 0)
        saved = (100.0 - 100.0 * bo / bi) if bi else 0.0
        pb = st.one("SELECT COALESCE(SUM(pages),0), COALESCE(SUM(COALESCE(kept,pages)),0) FROM files WHERE status='done'")
        reasons = st.q("SELECT COALESCE(reason,'?'), COUNT(*) FROM near GROUP BY reason ORDER BY 2 DESC")
        probs = st.q("SELECT status, COUNT(*) FROM files WHERE status IN ('error','encrypted','timeout','crash','locked') GROUP BY status")
        nc = st.one("SELECT COUNT(*) FROM files WHERE note IS NOT NULL")[0]
        near_rows = st.q("SELECT f.rel, n.pa, n.pb, n.score, n.reason FROM near n JOIN files f ON f.id=n.fid ORDER BY n.score, f.id LIMIT 300")
        prob_rows = st.q("""SELECT rel, status, error FROM files
                            WHERE status IN ('error','encrypted','timeout','crash','locked') ORDER BY id LIMIT 300""")

        def card(title, value, sub="", cls=""):
            return '<div class="k %s"><b>%s</b><span>%s</span><i>%s</i></div>' % (cls, e(str(value)), e(title), e(sub))
        cards = "".join([
            card("فایل پردازش‌شده", "{:,}".format(s.get("files_done", 0)), "از %s فایل" % "{:,}".format(s.get("files", 0))),
            card("صفحه‌ی تکراری حذف‌شده", "{:,}".format(s.get("pages_removed", 0)), "%s ← %s صفحه" % ("{:,}".format(pb[0]), "{:,}".format(pb[1])), "pink"),
            card("جفت صفحه‌ی خیلی نزدیک", "{:,}".format(s.get("near_pairs", 0)), "نیاز به بررسی شما", "amber"),
            card("فایل مشکل‌دار", "{:,}".format(s.get("problems", 0)), "دست‌نخورده ماندند", "red"),
            card("کاهش حجم", "%d%%" % round(saved), "%s ← %s" % (fmt_size(bi), fmt_size(bo)), "cyan"),
            card("زمان کار", fmt_dur(s.get("active_secs", 0)), "حالت " + ("سخت‌گیر" if self.strict else "متعادل")),
        ])
        rs = "".join("<li>%s: <b>%s</b></li>" % (e(NEAR_LABELS.get(k, "نامشخص")), "{:,}".format(n)) for k, n in reasons) or "<li>موردی نیست</li>"
        ps = "".join("<li>%s: <b>%s</b></li>" % (e(PROBLEM_LABELS.get(k, k)), "{:,}".format(n)) for k, n in probs) or "<li>موردی نیست</li>"
        nt = "".join("<tr><td dir=ltr>%s</td><td>%d و %d</td><td>%s</td><td>%d</td></tr>" % (e(r[0]), r[1], r[2], e(NEAR_LABELS.get(r[4], "—")), r[3])
                     for r in near_rows)
        pt = "".join("<tr><td dir=ltr>%s</td><td>%s</td><td dir=ltr>%s</td></tr>" % (e(r[0]), e(PROBLEM_LABELS.get(r[1], r[1])), e((r[2] or "")[:160]))
                     for r in prob_rows)
        css = ("body{margin:0;background:#070B24;color:#F4F7FF;font:15px/1.8 Tahoma,'Segoe UI',sans-serif;padding:32px}"
               "h1{margin:0 0 4px;font-size:30px}h2{margin:30px 0 10px;font-size:19px;color:#3DF2FF}.sub{color:#8E9BD6}"
               ".grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin-top:18px}"
               ".k{border:1px solid #23306E;border-radius:14px;padding:14px 16px;background:#0E1745}"
               ".k b{display:block;font-size:26px}.k span{color:#C9D2FF}.k i{display:block;color:#8E9BD6;font-style:normal;font-size:12.5px}"
               ".pink b{color:#FF3D9A}.amber b{color:#FFB84D}.red b{color:#FF8A8A}.cyan b{color:#3DF2FF}"
               "table{width:100%;border-collapse:collapse;font-size:13px}th,td{border-bottom:1px solid #1B2663;padding:6px 8px;text-align:right}"
               "th{color:#8E9BD6}td[dir=ltr]{text-align:left;word-break:break-all}ul{margin:0;padding-inline-start:20px}"
               ".note{color:#8E9BD6;font-size:13px;margin-top:6px}@media print{body{background:#fff;color:#000}.k{background:#fff}}")
        body = ('<h1>گزارش یکتاساز</h1><div class="sub">%s — پوشه: <bdi dir="ltr">%s</bdi></div><div class="grid">%s</div>'
                '<h2>جفت‌صفحه‌های خیلی نزدیک (به‌ترتیب نزدیکی)</h2><ul>%s</ul>'
                '<table><tr><th>فایل</th><th>صفحه‌ها</th><th>علت نگه داشتن</th><th>امتیاز تفاوت</th></tr>%s</table>'
                '<div class="note">فقط ۳۰۰ مورد نزدیک‌تر این‌جا آمده؛ فهرست کامل در very_close_pages.csv است. شماره‌ی صفحه‌ها مطابق فایل فعلی است.</div>'
                '<h2>فایل‌های مشکل‌دار</h2><ul>%s</ul>'
                '<table><tr><th>فایل</th><th>مشکل</th><th>توضیح</th></tr>%s</table>'
                '<h2>موارد دیگر</h2><ul><li>فایل‌هایی که فشرده‌سازی‌شان در بررسی رد شد: <b>%s</b></li></ul>'
                '<div class="note">فایل‌های کامل: removed_pages.csv ، very_close_pages.csv ، problems.csv ، log.txt ، summary.txt</div>') % (
            time.strftime("%Y-%m-%d %H:%M"), e(self.inp or ""), cards, rs, nt, ps, pt, "{:,}".format(nc))
        with open(os.path.join(d, "report.html"), "w", encoding="utf-8") as f:
            f.write('<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>گزارش یکتاساز</title>'
                    '<style>%s</style></head><body>%s</body></html>' % (css, body))


def _csv_parts(folder, name, header, rows):
    for old in os.listdir(folder):
        if old.startswith(name) and old.endswith(".csv"):
            os.remove(os.path.join(folder, old))
    part, n, f, w = 0, 0, None, None
    for row in rows:
        if f is None or n >= EXCEL_ROWS:
            if f:
                f.close()
            part += 1
            n = 0
            f = open(os.path.join(folder, "%s_%02d.csv" % (name, part) if part > 1 else "%s.csv" % name),
                     "w", encoding="utf-8-sig", newline="")
            w = csv.writer(f)
            w.writerow(header)
        w.writerow(row)
        n += 1
    if f is None:
        with open(os.path.join(folder, "%s.csv" % name), "w", encoding="utf-8-sig", newline="") as f:
            csv.writer(f).writerow(header)
    else:
        f.close()


def _long_path(p, force=False):
    """Windows: allow paths longer than 260 characters."""
    if os.name == "nt":
        p = os.path.abspath(p)
        if (force or len(p) > 240) and not p.startswith("\\\\?\\"):
            p = "\\\\?\\UNC\\" + p[2:] if p.startswith("\\\\") else "\\\\?\\" + p
    return p
